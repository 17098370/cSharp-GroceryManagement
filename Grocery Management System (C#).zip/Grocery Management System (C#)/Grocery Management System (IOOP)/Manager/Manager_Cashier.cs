﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Grocery_Management_System__IOOP_
{
    public partial class Manager_Cashier : Form
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=IOOP_Database;Integrated Security=True");

        public Manager_Cashier()
        {
            InitializeComponent();
        }

        //Search for particular cashier details and display cashier details in data grid view
        void FillDataGridView()
        {
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();

            SqlDataAdapter sqlDa = new SqlDataAdapter("ViewOrSearchCashier", sqlCon);
            sqlDa.SelectCommand.CommandType = CommandType.StoredProcedure;
            sqlDa.SelectCommand.Parameters.AddWithValue("@Name", txtSearch.Text.Trim());
            DataTable dtbl = new DataTable();
            sqlDa.Fill(dtbl);
            dgvCashierDetails.DataSource = dtbl;

            sqlCon.Close();
        }

        //Clear the text box and set date time picker to default
        public void Reset()
        {
            btnCashierID.Show();
            txtCashierID.Hide();
            txtCashierID.Text = txtUsername.Text = txtPassword.Text = txtFirstName.Text = txtLastName.Text = txtContactNo.Text = "";
            cmbContactNo.SelectedIndex = 0;
            btnAddCashier.Text = "Add Cashier";
        }

        //Display cashier details in data grid view and clear all text box when form load
        private void Manager_Cashier_Load(object sender, EventArgs e)
        {
            Reset();
            FillDataGridView();
        }

        //Add and Update cashier
        private void btnAddCashier_Click(object sender, EventArgs e)
        {
            try
            {
                if (sqlCon.State == ConnectionState.Closed)
                    sqlCon.Open();

                if (btnAddCashier.Text == "Add Cashier")
                {
                    if (string.IsNullOrWhiteSpace(txtUsername.Text) || string.IsNullOrWhiteSpace(txtPassword.Text) || string.IsNullOrWhiteSpace(txtFirstName.Text) || string.IsNullOrWhiteSpace(txtLastName.Text) || string.IsNullOrWhiteSpace(txtContactNo.Text))
                        MessageBox.Show("Please fill in the empty blanks!", "Cashier Added Unsuccessfully", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    else if (string.IsNullOrEmpty(txtCashierID.Text))
                        MessageBox.Show("Please generate a Cashier ID!", "Cashier Added Unsuccessfully", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    else
                    {
                        SqlCommand sqlCmd = new SqlCommand("AddOrUpdateCashier", sqlCon);
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.Parameters.AddWithValue("@mode", "Add");
                        sqlCmd.Parameters.AddWithValue("@POS_ID", txtCashierID.Text); //Trim() will remove extra spaces on left and right side of a string
                        sqlCmd.Parameters.AddWithValue("@Username", txtUsername.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@Login_Password", txtPassword.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@Login_User", "Cashier"); //Set "Cashier" value to Login_User column
                        sqlCmd.Parameters.AddWithValue("@First_Name", txtFirstName.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@Last_Name", txtLastName.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@Contact_No", cmbContactNo.GetItemText(cmbContactNo.SelectedItem) + txtContactNo.Text.Trim()); //http://stackoverflow.com/questions/25669344/how-to-insert-combo-box-value-into-sql-server-using-c-sharp

                        sqlCmd.ExecuteNonQuery();

                        Reset();
                        MessageBox.Show("Cashier account is registered successfully!", "Cashier Added Successfully", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    if (string.IsNullOrWhiteSpace(txtUsername.Text) || string.IsNullOrWhiteSpace(txtPassword.Text) || string.IsNullOrWhiteSpace(txtFirstName.Text) || string.IsNullOrWhiteSpace(txtLastName.Text) || string.IsNullOrWhiteSpace(txtContactNo.Text))
                        MessageBox.Show("Please fill in the empty blanks!");

                    else
                    {
                        SqlCommand sqlCmd = new SqlCommand("AddOrUpdateCashier", sqlCon);
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.Parameters.AddWithValue("@mode", "Update");
                        sqlCmd.Parameters.AddWithValue("@POS_ID", txtCashierID.Text);
                        sqlCmd.Parameters.AddWithValue("@Username", txtUsername.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@Login_Password", txtPassword.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@Login_User", "Cashier"); //Set "Cashier" value to Login_User column
                        sqlCmd.Parameters.AddWithValue("@First_Name", txtFirstName.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@Last_Name", txtLastName.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@Contact_No", cmbContactNo.GetItemText(cmbContactNo.SelectedItem) + txtContactNo.Text.Trim());

                        sqlCmd.ExecuteNonQuery();

                        Reset();
                        MessageBox.Show("Cashier account is updated successfully!", "Cashier Updated Successfully", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }   
                FillDataGridView();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
            finally
            {
                sqlCon.Close();
            }
        }

        //Display details of selected rows on text box and date time picker
        private void dgvCashierDetails_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvCashierDetails.Rows.Count != 0)
            {
                btnCashierID.Hide();
                txtCashierID.Show();

                txtCashierID.Text = dgvCashierDetails.CurrentRow.Cells[0].Value.ToString();
                txtUsername.Text = dgvCashierDetails.CurrentRow.Cells[1].Value.ToString();
                txtPassword.Text = dgvCashierDetails.CurrentRow.Cells[2].Value.ToString();
                txtFirstName.Text = dgvCashierDetails.CurrentRow.Cells[3].Value.ToString();
                txtLastName.Text = dgvCashierDetails.CurrentRow.Cells[4].Value.ToString();
                cmbContactNo.Text = dgvCashierDetails.CurrentRow.Cells[5].Value.ToString().Substring(0, 3); //http://stackoverflow.com/questions/17386978/how-to-get-first-3-characters-of-a-textboxs-text, http://stackoverflow.com/questions/28798631/pass-the-selected-value-in-datagridview-to-combobox
                txtContactNo.Text = dgvCashierDetails.CurrentRow.Cells[5].Value.ToString().Remove(0, 3);

                btnAddCashier.Text = "Update Cashier";
            }
            else
                MessageBox.Show("Please add in cashier details!", "No Cashier Details Found", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        //Run Reset() Function
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Reset();
        }

        //Delete selected cashier details
        private void btnDeleteCashier_Click(object sender, EventArgs e)
        {
             DialogResult Result = MessageBox.Show("Are you sure you want to delete?", "Delete Selected Cashier", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

             if (Result == DialogResult.Yes)
             {
                 try
                 {
                     if (sqlCon.State == ConnectionState.Closed)
                         sqlCon.Open();

                     SqlCommand sqlCmd = new SqlCommand("DeleteCashier", sqlCon);
                     sqlCmd.CommandType = CommandType.StoredProcedure;
                     sqlCmd.Parameters.AddWithValue("@Pos_ID", txtCashierID.Text);

                     sqlCmd.ExecuteNonQuery();

                     Reset();
                     FillDataGridView();
                 }
                 catch (Exception ex)
                 {
                     MessageBox.Show(ex.Message, "Error Message");
                 }
             }
        }

        //Run FillDataGridView() Function
        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                FillDataGridView();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }

            if (txtSearch.Text.Replace(" ", String.Empty) == "")
                FillDataGridView();
        }

        //Clear Search textbox
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtSearch.Clear();
        }

        //Generate a Promotion ID after button clicked
        private void btnCashierID_Click(object sender, EventArgs e)
        {
            SqlCommand sqlCmd = new SqlCommand("SELECT TOP 1 POS_ID FROM Account_Login ORDER BY POS_ID DESC", sqlCon); //http://www.w3schools.com/SQl/sql_func_last.asp

            try
            {
                if (sqlCon.State == ConnectionState.Closed)
                    sqlCon.Open();

                using (SqlDataReader sqlRead = sqlCmd.ExecuteReader())
                {
                    if (sqlRead.HasRows)
                    {
                        sqlRead.Close();

                        string CashierID = "POS";

                        //Use to detect how many 0 should be there 

                        for (int i = 0; i < ((sqlCmd.ExecuteScalar().ToString().Remove(0, 3).Length) - ((int.Parse(sqlCmd.ExecuteScalar().ToString().Remove(0, 3)) + 1)).ToString().Length); i++) //http://stackoverflow.com/questions/9761545/get-data-from-sql-query-into-textbox                         
                            CashierID += "0";

                        //Use to increment the ID
                        txtCashierID.Text = (CashierID += (int.Parse(sqlCmd.ExecuteScalar().ToString().Remove(0, 3)) + 1).ToString()).ToString();

                    }

                    else
                        txtCashierID.Text = "POS001";

                    txtCashierID.Show();
                    btnCashierID.Hide();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
            finally
            {
                sqlCon.Close();
            }
        }

        private void NumbersOnly_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !Char.IsDigit(e.KeyChar) && (e.KeyChar != 8);
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            FillDataGridView();
        }
    }
}
