﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Grocery_Management_System__IOOP_
{
    public partial class Manager_Orders : Form
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=IOOP_Database;Integrated Security=True");

        public Manager_Orders()
        {
            InitializeComponent();
        }

        private void Manager_Orders_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'iOOP_DatabaseDataSet.Customer_Order' table. You can move, or remove it, as needed.
            this.customer_OrderTableAdapter.Fill(this.iOOP_DatabaseDataSet.Customer_Order);

        }

        private void dgvCustomerOrderDetails_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvCustomerOrderDetails.Rows.Count != 0)
            {
                int orderID;
                orderID = int.Parse(dgvCustomerOrderDetails.CurrentRow.Cells[0].Value.ToString());

                if (sqlCon.State == ConnectionState.Closed)
                    sqlCon.Open();

                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * FROM Order_Details WHERE Order_ID = " + orderID, sqlCon);
                DataTable dtbl = new DataTable();
                sqlDa.Fill(dtbl);
                Manager_Order_Details F_Manager_Order_Details = new Manager_Order_Details();
                F_Manager_Order_Details.dgvCustomerOrderDetails.DataSource = dtbl;
                F_Manager_Order_Details.Show();

                sqlCon.Close();
            }
            else
                MessageBox.Show("There are no customer orders!", "No Customer Orders Found", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();

            SqlDataAdapter sqlDa = new SqlDataAdapter("ViewOrSearchOrders", sqlCon);
            sqlDa.SelectCommand.CommandType = CommandType.StoredProcedure;
            sqlDa.SelectCommand.Parameters.AddWithValue("@Order_ID", txtSearch.Text.Trim());
            DataTable dtbl = new DataTable();
            sqlDa.Fill(dtbl);
            dgvCustomerOrderDetails.DataSource = dtbl;

            sqlCon.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtSearch.Clear();
        }
    }
}
