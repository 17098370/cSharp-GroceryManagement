﻿namespace Grocery_Management_System__IOOP_
{
    partial class Manager_Calculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlTop = new System.Windows.Forms.Panel();
            this.btnClose = new System.Windows.Forms.Button();
            this.pnlCalculator = new System.Windows.Forms.Panel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.btnDone = new System.Windows.Forms.Button();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.btn50c = new System.Windows.Forms.Button();
            this.btn20c = new System.Windows.Forms.Button();
            this.btn5c = new System.Windows.Forms.Button();
            this.btn10c = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.btnRm1 = new System.Windows.Forms.Button();
            this.btnRm100 = new System.Windows.Forms.Button();
            this.btnRm50 = new System.Windows.Forms.Button();
            this.btnRm20 = new System.Windows.Forms.Button();
            this.btnRm10 = new System.Windows.Forms.Button();
            this.btnRm5 = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.lblUnitPrice = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.pnlTop.SuspendLayout();
            this.pnlCalculator.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTop
            // 
            this.pnlTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(89)))), ((int)(((byte)(152)))));
            this.pnlTop.Controls.Add(this.btnClose);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(329, 34);
            this.pnlTop.TabIndex = 6;
            this.pnlTop.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlTop_MouseDown);
            this.pnlTop.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlTop_MouseMove);
            this.pnlTop.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnlTop_MouseUp);
            // 
            // btnClose
            // 
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F);
            this.btnClose.ForeColor = System.Drawing.Color.White;
            this.btnClose.Location = new System.Drawing.Point(295, 0);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(30, 34);
            this.btnClose.TabIndex = 6;
            this.btnClose.Text = "x";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // pnlCalculator
            // 
            this.pnlCalculator.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(235)))), ((int)(((byte)(238)))));
            this.pnlCalculator.Controls.Add(this.tableLayoutPanel4);
            this.pnlCalculator.Controls.Add(this.tableLayoutPanel3);
            this.pnlCalculator.Controls.Add(this.tableLayoutPanel2);
            this.pnlCalculator.Controls.Add(this.tableLayoutPanel1);
            this.pnlCalculator.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlCalculator.Location = new System.Drawing.Point(0, 34);
            this.pnlCalculator.Name = "pnlCalculator";
            this.pnlCalculator.Size = new System.Drawing.Size(328, 361);
            this.pnlCalculator.TabIndex = 5;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.16201F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.83799F));
            this.tableLayoutPanel3.Controls.Add(this.btnClear, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.btnDone, 1, 0);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 303);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 58F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(322, 58);
            this.tableLayoutPanel3.TabIndex = 36;
            // 
            // btnDone
            // 
            this.btnDone.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(89)))), ((int)(((byte)(152)))));
            this.btnDone.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnDone.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(201)))), ((int)(((byte)(206)))));
            this.btnDone.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDone.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDone.ForeColor = System.Drawing.Color.White;
            this.btnDone.Location = new System.Drawing.Point(161, 3);
            this.btnDone.Name = "btnDone";
            this.btnDone.Size = new System.Drawing.Size(158, 52);
            this.btnDone.TabIndex = 29;
            this.btnDone.Text = "DONE";
            this.btnDone.UseVisualStyleBackColor = false;
            this.btnDone.Click += new System.EventHandler(this.btnDone_Click);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.btn50c, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.btn20c, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.btn5c, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.btn10c, 0, 2);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(236, 79);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 4;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(89, 224);
            this.tableLayoutPanel2.TabIndex = 34;
            // 
            // btn50c
            // 
            this.btn50c.BackColor = System.Drawing.Color.White;
            this.btn50c.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn50c.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btn50c.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn50c.Font = new System.Drawing.Font("Segoe UI", 17F, System.Drawing.FontStyle.Bold);
            this.btn50c.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(89)))), ((int)(((byte)(152)))));
            this.btn50c.Location = new System.Drawing.Point(3, 3);
            this.btn50c.Name = "btn50c";
            this.btn50c.Size = new System.Drawing.Size(83, 50);
            this.btn50c.TabIndex = 30;
            this.btn50c.Text = "50c";
            this.btn50c.UseVisualStyleBackColor = false;
            this.btn50c.Click += new System.EventHandler(this.btnRinggit_Click);
            // 
            // btn20c
            // 
            this.btn20c.BackColor = System.Drawing.Color.White;
            this.btn20c.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn20c.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btn20c.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn20c.Font = new System.Drawing.Font("Segoe UI", 17F, System.Drawing.FontStyle.Bold);
            this.btn20c.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(89)))), ((int)(((byte)(152)))));
            this.btn20c.Location = new System.Drawing.Point(3, 59);
            this.btn20c.Name = "btn20c";
            this.btn20c.Size = new System.Drawing.Size(83, 50);
            this.btn20c.TabIndex = 31;
            this.btn20c.Text = "20c";
            this.btn20c.UseVisualStyleBackColor = false;
            this.btn20c.Click += new System.EventHandler(this.btnRinggit_Click);
            // 
            // btn5c
            // 
            this.btn5c.BackColor = System.Drawing.Color.White;
            this.btn5c.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn5c.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btn5c.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn5c.Font = new System.Drawing.Font("Segoe UI", 17F, System.Drawing.FontStyle.Bold);
            this.btn5c.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(89)))), ((int)(((byte)(152)))));
            this.btn5c.Location = new System.Drawing.Point(3, 171);
            this.btn5c.Name = "btn5c";
            this.btn5c.Size = new System.Drawing.Size(83, 50);
            this.btn5c.TabIndex = 33;
            this.btn5c.Text = "5c";
            this.btn5c.UseVisualStyleBackColor = false;
            this.btn5c.Click += new System.EventHandler(this.btnRinggit_Click);
            // 
            // btn10c
            // 
            this.btn10c.BackColor = System.Drawing.Color.White;
            this.btn10c.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn10c.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btn10c.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn10c.Font = new System.Drawing.Font("Segoe UI", 17F, System.Drawing.FontStyle.Bold);
            this.btn10c.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(89)))), ((int)(((byte)(152)))));
            this.btn10c.Location = new System.Drawing.Point(3, 115);
            this.btn10c.Name = "btn10c";
            this.btn10c.Size = new System.Drawing.Size(83, 50);
            this.btn10c.TabIndex = 32;
            this.btn10c.Text = "10c";
            this.btn10c.UseVisualStyleBackColor = false;
            this.btn10c.Click += new System.EventHandler(this.btnRinggit_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.btnRm1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnRm100, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.btnRm50, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.btnRm20, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnRm10, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.btnRm5, 0, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 79);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(230, 224);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // btnRm1
            // 
            this.btnRm1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnRm1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(89)))), ((int)(((byte)(152)))));
            this.btnRm1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnRm1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(201)))), ((int)(((byte)(206)))));
            this.btnRm1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRm1.Font = new System.Drawing.Font("Segoe UI", 17F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRm1.ForeColor = System.Drawing.Color.White;
            this.btnRm1.Location = new System.Drawing.Point(3, 4);
            this.btnRm1.Name = "btnRm1";
            this.btnRm1.Size = new System.Drawing.Size(109, 65);
            this.btnRm1.TabIndex = 35;
            this.btnRm1.Text = "RM 1";
            this.btnRm1.UseVisualStyleBackColor = false;
            this.btnRm1.Click += new System.EventHandler(this.btnRinggit_Click);
            // 
            // btnRm100
            // 
            this.btnRm100.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnRm100.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(89)))), ((int)(((byte)(152)))));
            this.btnRm100.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(201)))), ((int)(((byte)(206)))));
            this.btnRm100.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRm100.Font = new System.Drawing.Font("Segoe UI", 17F, System.Drawing.FontStyle.Bold);
            this.btnRm100.ForeColor = System.Drawing.Color.White;
            this.btnRm100.Location = new System.Drawing.Point(118, 153);
            this.btnRm100.Name = "btnRm100";
            this.btnRm100.Size = new System.Drawing.Size(109, 65);
            this.btnRm100.TabIndex = 37;
            this.btnRm100.Text = "RM 100";
            this.btnRm100.UseVisualStyleBackColor = false;
            this.btnRm100.Click += new System.EventHandler(this.btnRinggit_Click);
            // 
            // btnRm50
            // 
            this.btnRm50.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnRm50.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(89)))), ((int)(((byte)(152)))));
            this.btnRm50.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(201)))), ((int)(((byte)(206)))));
            this.btnRm50.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRm50.Font = new System.Drawing.Font("Segoe UI", 17F, System.Drawing.FontStyle.Bold);
            this.btnRm50.ForeColor = System.Drawing.Color.White;
            this.btnRm50.Location = new System.Drawing.Point(118, 78);
            this.btnRm50.Name = "btnRm50";
            this.btnRm50.Size = new System.Drawing.Size(109, 65);
            this.btnRm50.TabIndex = 36;
            this.btnRm50.Text = "RM 50";
            this.btnRm50.UseVisualStyleBackColor = false;
            this.btnRm50.Click += new System.EventHandler(this.btnRinggit_Click);
            // 
            // btnRm20
            // 
            this.btnRm20.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnRm20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(89)))), ((int)(((byte)(152)))));
            this.btnRm20.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(201)))), ((int)(((byte)(206)))));
            this.btnRm20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRm20.Font = new System.Drawing.Font("Segoe UI", 17F, System.Drawing.FontStyle.Bold);
            this.btnRm20.ForeColor = System.Drawing.Color.White;
            this.btnRm20.Location = new System.Drawing.Point(118, 4);
            this.btnRm20.Name = "btnRm20";
            this.btnRm20.Size = new System.Drawing.Size(109, 65);
            this.btnRm20.TabIndex = 23;
            this.btnRm20.Text = "RM 20";
            this.btnRm20.UseVisualStyleBackColor = false;
            this.btnRm20.Click += new System.EventHandler(this.btnRinggit_Click);
            // 
            // btnRm10
            // 
            this.btnRm10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnRm10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(89)))), ((int)(((byte)(152)))));
            this.btnRm10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnRm10.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(201)))), ((int)(((byte)(206)))));
            this.btnRm10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRm10.Font = new System.Drawing.Font("Segoe UI", 17F, System.Drawing.FontStyle.Bold);
            this.btnRm10.ForeColor = System.Drawing.Color.White;
            this.btnRm10.Location = new System.Drawing.Point(3, 153);
            this.btnRm10.Name = "btnRm10";
            this.btnRm10.Size = new System.Drawing.Size(109, 65);
            this.btnRm10.TabIndex = 7;
            this.btnRm10.Text = "RM 10";
            this.btnRm10.UseVisualStyleBackColor = false;
            this.btnRm10.Click += new System.EventHandler(this.btnRinggit_Click);
            // 
            // btnRm5
            // 
            this.btnRm5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnRm5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(89)))), ((int)(((byte)(152)))));
            this.btnRm5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnRm5.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(201)))), ((int)(((byte)(206)))));
            this.btnRm5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRm5.Font = new System.Drawing.Font("Segoe UI", 17F, System.Drawing.FontStyle.Bold);
            this.btnRm5.ForeColor = System.Drawing.Color.White;
            this.btnRm5.Location = new System.Drawing.Point(3, 78);
            this.btnRm5.Name = "btnRm5";
            this.btnRm5.Size = new System.Drawing.Size(109, 65);
            this.btnRm5.TabIndex = 34;
            this.btnRm5.Text = "RM 5";
            this.btnRm5.UseVisualStyleBackColor = false;
            this.btnRm5.Click += new System.EventHandler(this.btnRinggit_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.White;
            this.btnClear.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnClear.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClear.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(89)))), ((int)(((byte)(152)))));
            this.btnClear.Location = new System.Drawing.Point(3, 3);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(152, 52);
            this.btnClear.TabIndex = 35;
            this.btnClear.Text = "CLEAR";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Controls.Add(this.lblUnitPrice, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.label11, 0, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 28.57143F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 71.42857F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(328, 77);
            this.tableLayoutPanel4.TabIndex = 37;
            // 
            // lblUnitPrice
            // 
            this.lblUnitPrice.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblUnitPrice.BackColor = System.Drawing.Color.White;
            this.lblUnitPrice.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUnitPrice.ForeColor = System.Drawing.Color.Black;
            this.lblUnitPrice.Location = new System.Drawing.Point(3, 26);
            this.lblUnitPrice.Name = "lblUnitPrice";
            this.lblUnitPrice.Size = new System.Drawing.Size(322, 45);
            this.lblUnitPrice.TabIndex = 33;
            this.lblUnitPrice.Text = "RM 0.00";
            this.lblUnitPrice.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(3, 6);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(62, 15);
            this.label11.TabIndex = 32;
            this.label11.Text = "Unit Price";
            // 
            // Manager_Calculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(329, 396);
            this.Controls.Add(this.pnlTop);
            this.Controls.Add(this.pnlCalculator);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Manager_Calculator";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Manager_Calculator";
            this.pnlTop.ResumeLayout(false);
            this.pnlCalculator.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Panel pnlCalculator;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnDone;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Button btn50c;
        private System.Windows.Forms.Button btn20c;
        private System.Windows.Forms.Button btn5c;
        private System.Windows.Forms.Button btn10c;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button btnRm1;
        private System.Windows.Forms.Button btnRm100;
        private System.Windows.Forms.Button btnRm50;
        private System.Windows.Forms.Button btnRm20;
        private System.Windows.Forms.Button btnRm10;
        private System.Windows.Forms.Button btnRm5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label lblUnitPrice;
        private System.Windows.Forms.Label label11;
    }
}