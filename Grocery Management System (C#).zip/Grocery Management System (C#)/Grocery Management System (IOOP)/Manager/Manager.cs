﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Grocery_Management_System__IOOP_
{
    public partial class Manager : Form
    {
        public string LogoutTo;

        Manager_Products F_Manager_Products = new Manager_Products();
        Manager_Promotions F_Manager_Promotions = new Manager_Promotions();
        Manager_Cashier F_Manager_Cashier = new Manager_Cashier();
        Manager_Membership F_Manager_Membership = new Manager_Membership();
        Manager_Reports F_Manager_Reports = new Manager_Reports();
        Manager_Orders F_Manager_Orders = new Manager_Orders();

        public Manager()
        {
            InitializeComponent();
        }
       
        //System shadow
        protected override CreateParams CreateParams
        {
            get
            {
                const int CS_DROPSHADOW = 0x20000;
                CreateParams cp = base.CreateParams;
                cp.ClassStyle |= CS_DROPSHADOW;
                return cp;
            }
        }

        //Close system
        private void btnClose_Click(object sender, EventArgs e)
        {
            DialogResult Result = MessageBox.Show("Are you sure you want to exit?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (Result == DialogResult.Yes)
                Application.Exit();
        }

        //Minimize system
        private void btnMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        //Display main page when Logout button clicked
        private void btnLogout_Click(object sender, EventArgs e)
        {
            DialogResult Result = MessageBox.Show("Are you sure you want to Logout?", "Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (Result == DialogResult.Yes)
            {
                if (LogoutTo == "Cashier")
                {
                    Cashier F_Cashier = new Cashier();

                    this.Hide();
                    F_Cashier.Show();
                }
                else if (LogoutTo == "Main")
                {
                    Main F_Main = new Main();

                    this.Close();
                    F_Main.Show();
                }
            }
        }

        //Dragable Borderless Form
        private bool _dragging = false;
        private Point _start_point = new Point(0, 0);

        private void pnlTop_MouseDown(object sender, MouseEventArgs e)
        {
            _dragging = true;
            _start_point = new Point(e.X, e.Y);
        }

        private void pnlTop_MouseUp(object sender, MouseEventArgs e)
        {
            _dragging = false;
        }

        private void pnlTop_MouseMove(object sender, MouseEventArgs e)
        {
            if (_dragging)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X - this._start_point.X, p.Y - this._start_point.Y);
            }
        }

        //Display Manager Products form when Products button clicked
        private void btnProducts_Click(object sender, EventArgs e)
        {
            F_Manager_Products.TopLevel = false;
            F_Manager_Products.AutoScroll = true;
            pnlManager.Controls.Add(F_Manager_Products);

            F_Manager_Products.Show();

            F_Manager_Promotions.Hide();
            F_Manager_Cashier.Hide();
            F_Manager_Membership.Hide();
            F_Manager_Reports.Hide();
            F_Manager_Orders.Hide();

            btnProducts.BackColor = ColorTranslator.FromHtml("#C5C6CC");
            btnPromotions.BackColor = ColorTranslator.FromHtml("#DCDDE3");
            btnCashier.BackColor = ColorTranslator.FromHtml("#DCDDE3");
            btnMembership.BackColor = ColorTranslator.FromHtml("#DCDDE3");
            btnOrders.BackColor = ColorTranslator.FromHtml("#DCDDE3");
            btnReports.BackColor = ColorTranslator.FromHtml("#DCDDE3");
        }

        //Display Manager Promotions form when Promotions button clicked
        private void btnPromotions_Click(object sender, EventArgs e)
        {
            F_Manager_Promotions.TopLevel = false;
            F_Manager_Promotions.AutoScroll = true;
            pnlManager.Controls.Add(F_Manager_Promotions);

            F_Manager_Promotions.Show();
            F_Manager_Promotions.Reset();
            F_Manager_Promotions.txtSearch.Clear();
            F_Manager_Promotions.Refresh();

            F_Manager_Products.Hide();
            F_Manager_Cashier.Hide();
            F_Manager_Membership.Hide();
            F_Manager_Reports.Hide();
            F_Manager_Orders.Hide();

            btnProducts.BackColor = ColorTranslator.FromHtml("#DCDDE3");
            btnPromotions.BackColor = ColorTranslator.FromHtml("#C5C6CC");
            btnCashier.BackColor = ColorTranslator.FromHtml("#DCDDE3");
            btnMembership.BackColor = ColorTranslator.FromHtml("#DCDDE3");
            btnOrders.BackColor = ColorTranslator.FromHtml("#DCDDE3");
            btnReports.BackColor = ColorTranslator.FromHtml("#DCDDE3");
        }

        //Display Manager Inventory form when Inventory button clicked
        private void btnCashier_Click(object sender, EventArgs e)
        {
            F_Manager_Cashier.TopLevel = false;
            F_Manager_Cashier.AutoScroll = true;
            pnlManager.Controls.Add(F_Manager_Cashier);

            F_Manager_Cashier.Show();
            F_Manager_Cashier.Reset();
            F_Manager_Cashier.txtSearch.Clear();
            F_Manager_Cashier.Refresh();

            F_Manager_Products.Hide();
            F_Manager_Promotions.Hide();
            F_Manager_Membership.Hide();
            F_Manager_Reports.Hide();
            F_Manager_Orders.Hide();

            btnProducts.BackColor = ColorTranslator.FromHtml("#DCDDE3");
            btnPromotions.BackColor = ColorTranslator.FromHtml("#DCDDE3");
            btnCashier.BackColor = ColorTranslator.FromHtml("#C5C6CC");
            btnMembership.BackColor = ColorTranslator.FromHtml("#DCDDE3");
            btnOrders.BackColor = ColorTranslator.FromHtml("#DCDDE3");
            btnReports.BackColor = ColorTranslator.FromHtml("#DCDDE3");
        }

        //Display Manager Membership form when Membership button clicked
        private void btnMembership_Click(object sender, EventArgs e)
        {
            F_Manager_Membership.TopLevel = false;
            F_Manager_Membership.AutoScroll = true;
            pnlManager.Controls.Add(F_Manager_Membership);

            F_Manager_Membership.Show();
            F_Manager_Membership.txtSearch.Clear();
            F_Manager_Membership.btnAddMember.Text = "Add Member";
            F_Manager_Membership.Refresh();

            F_Manager_Products.Hide();
            F_Manager_Promotions.Hide();
            F_Manager_Cashier.Hide();
            F_Manager_Reports.Hide();
            F_Manager_Orders.Hide();

            btnProducts.BackColor = ColorTranslator.FromHtml("#DCDDE3");
            btnPromotions.BackColor = ColorTranslator.FromHtml("#DCDDE3");
            btnCashier.BackColor = ColorTranslator.FromHtml("#DCDDE3");
            btnMembership.BackColor = ColorTranslator.FromHtml("#C5C6CC");
            btnOrders.BackColor = ColorTranslator.FromHtml("#DCDDE3");
            btnReports.BackColor = ColorTranslator.FromHtml("#DCDDE3");
        }

        //Display Manager Reports form when Reports button clicked
        private void btnReports_Click(object sender, EventArgs e)
        {
            F_Manager_Reports.TopLevel = false;
            F_Manager_Reports.AutoScroll = true;
            pnlManager.Controls.Add(F_Manager_Reports);

            F_Manager_Reports.Show();

            F_Manager_Products.Hide();
            F_Manager_Promotions.Hide();
            F_Manager_Cashier.Hide();
            F_Manager_Membership.Hide();
            F_Manager_Orders.Hide();

            btnProducts.BackColor = ColorTranslator.FromHtml("#DCDDE3");
            btnPromotions.BackColor = ColorTranslator.FromHtml("#DCDDE3");
            btnCashier.BackColor = ColorTranslator.FromHtml("#DCDDE3");
            btnMembership.BackColor = ColorTranslator.FromHtml("#DCDDE3");
            btnOrders.BackColor = ColorTranslator.FromHtml("#DCDDE3");
            btnReports.BackColor = ColorTranslator.FromHtml("#C5C6CC");
        }

        private void btnOrders_Click(object sender, EventArgs e)
        {
            F_Manager_Orders.TopLevel = false;
            F_Manager_Orders.AutoScroll = true;
            pnlManager.Controls.Add(F_Manager_Orders);

            F_Manager_Orders.Show();

            F_Manager_Products.Hide();
            F_Manager_Promotions.Hide();
            F_Manager_Cashier.Hide();
            F_Manager_Membership.Hide();
            F_Manager_Reports.Hide();

            btnProducts.BackColor = ColorTranslator.FromHtml("#DCDDE3");
            btnPromotions.BackColor = ColorTranslator.FromHtml("#DCDDE3");
            btnCashier.BackColor = ColorTranslator.FromHtml("#DCDDE3");
            btnMembership.BackColor = ColorTranslator.FromHtml("#DCDDE3");
            btnOrders.BackColor = ColorTranslator.FromHtml("#C5C6CC");
            btnReports.BackColor = ColorTranslator.FromHtml("#DCDDE3");

        }

        //Display Reports form when form load
        private void Manager_Load(object sender, EventArgs e)
        {
            F_Manager_Reports.TopLevel = false;
            F_Manager_Reports.AutoScroll = true;
            pnlManager.Controls.Add(F_Manager_Reports);
            
            F_Manager_Reports.Show();

            //https://msdn.microsoft.com/en-us/library/zdtaw1bw.aspx
            //Display current dates and day
            DateTime dateValue = DateTime.Now;
            lblDate.Text = dateValue.ToString("D");
        }

        //Display current system time
        private void tmrTime_Tick(object sender, EventArgs e)
        {
            DateTime Current_Time = DateTime.Now;
            lblTime.Text = Current_Time.ToString("hh:mm:ss  tt");
        }

        private void btnCashierView_Click(object sender, EventArgs e)
        {
            Cashier F_Cashier = new Cashier();

            this.Hide();
            F_Cashier.isManager = "true"; //Manager no need to enter password when enter manager view from cashier page
            F_Cashier.lblUser.Text = "Manager Jack";
            F_Cashier.Show();
            //(this.Owner as Manager).Hide();
        } 
    }
}
