﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Grocery_Management_System__IOOP_
{
    public partial class Manager_Products : Form
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=IOOP_Database;Integrated Security=True");

        public Manager_Products()
        {
            InitializeComponent();
        }

        private void Manager_Products_Load(object sender, EventArgs e)
        {
            //ClearData();
            DisplayData();

            try
            {
                if (sqlCon.State == ConnectionState.Closed)
                    sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("SELECT * FROM Category", sqlCon);

                using (SqlDataReader sqlDr = sqlCmd.ExecuteReader())
                {
                    if (sqlDr.HasRows)
                    {
                        while (sqlDr.Read())
                        {
                            cmbCategory.Items.Add(sqlDr["Category_Name"].ToString());
                        }
                        cmbCategory.SelectedIndex = 0;
                    }

                    else
                        cmbCategory.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
            finally
            {
                sqlCon.Close();
            } 
        }

        //Display Data in DataGridView  
        private void DisplayData()
        {
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();

            DataTable dtbl = new DataTable();
            SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * FROM Product", sqlCon);
            sqlDa.Fill(dtbl);
            dgvProductDetails.DataSource = dtbl;

            //cmbCategory.DataBindings[0].ReadValue();
            
            sqlCon.Close();
        }

        //Clear Data  
        private void ClearData()
        {
            btnProductID.Show();
            txtProductID.Hide();
            txtProductID.Text = txtBarcode.Text = txtProductName.Text = txtUnitPrice.Text = txtStock.Text = "";
            cmbCategory.SelectedIndex = 0;
            btnAddProduct.Text = "Add Product";
        }

        //Allow System to Read which Row is Selected
        private void dgvProductDetails_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvProductDetails.Rows.Count != 0)
            {
                btnProductID.Hide();
                txtProductID.Show();

                txtProductID.Text = dgvProductDetails.CurrentRow.Cells[0].Value.ToString();
                txtBarcode.Text = dgvProductDetails.CurrentRow.Cells[1].Value.ToString();
                cmbCategory.Text = dgvProductDetails.CurrentRow.Cells[2].Value.ToString();
                txtProductName.Text = dgvProductDetails.CurrentRow.Cells[3].Value.ToString();
                txtUnitPrice.Text = "RM " + float.Parse(dgvProductDetails.CurrentRow.Cells[4].Value.ToString()).ToString("N2");
                txtStock.Text = dgvProductDetails.CurrentRow.Cells[5].Value.ToString(); //http://stackoverflow.com/questions/17386978/how-to-get-first-3-characters-of-a-textboxs-text, http://stackoverflow.com/questions/28798631/pass-the-selected-value-in-datagridview-to-combobox

                btnAddProduct.Text = "Update Product";
            }
            else
                MessageBox.Show("Please add in product details!", "No Product Found", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        //http://www.c-sharpcorner.com/UploadFile/1e050f/insert-update-and-delete-record-in-datagridview-C-Sharp/
        //Allow Manager to Add Product's Details
        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            try
            {
                string category_ID;

                if (sqlCon.State == ConnectionState.Closed)
                    sqlCon.Open();

                SqlCommand sqlcmd = new SqlCommand("SELECT COUNT(*) FROM Product WHERE Barcode = @check", sqlCon);
                sqlcmd.Parameters.AddWithValue("@check", txtBarcode.Text);
                int countBarcode = (int)sqlcmd.ExecuteScalar();

                if (btnAddProduct.Text == "Add Product")
                {
                    if (cmbCategory.Text == "")
                        MessageBox.Show("Please create a product catogory by clicking the + beside Product Category!", "Product Category Is Empty", MessageBoxButtons.OK, MessageBoxIcon.Error);
 
                    else if (string.IsNullOrWhiteSpace(txtBarcode.Text) || string.IsNullOrWhiteSpace(txtProductName.Text) || string.IsNullOrWhiteSpace(txtUnitPrice.Text) || string.IsNullOrWhiteSpace(txtStock.Text))
                        MessageBox.Show("Please fill in the empty blanks!", "Product Added Unsuccessfully", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    else if (string.IsNullOrEmpty(txtProductID.Text))
                        MessageBox.Show("Please generate a Cashier ID!", "Product Added Unsuccessfully", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    else if (txtUnitPrice.Text == "RM 0.00")
                        MessageBox.Show("Please provide valid value for unit price!", "Product Added Unsuccessfully", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    else if (countBarcode != 0)
                        MessageBox.Show("Barcode existed, please provide a different barcode!", "Product Added Unsuccessfully", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    else
                    {
                        SqlCommand sqlCom = new SqlCommand("SELECT Category_ID FROM Category WHERE Category_Name ='" + cmbCategory.GetItemText(cmbCategory.SelectedItem) + "'", sqlCon);
                        SqlCommand sqlCmd = new SqlCommand("INSERT INTO Product VALUES(@Product_ID, @Barcode, @Category_ID, @Category_Name, @Product_Name, @Unit_Price, @Stock)", sqlCon);
                        
                        category_ID = sqlCom.ExecuteScalar().ToString();

                        sqlCmd.Parameters.AddWithValue("@Product_ID", txtProductID.Text);
                        sqlCmd.Parameters.AddWithValue("@Barcode", txtBarcode.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@Category_ID", category_ID);
                        sqlCmd.Parameters.AddWithValue("@Category_Name", cmbCategory.GetItemText(cmbCategory.SelectedItem));
                        sqlCmd.Parameters.AddWithValue("@Product_Name", txtProductName.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@Unit_Price", float.Parse(txtUnitPrice.Text.Remove(0, 3)).ToString("N2"));
                        sqlCmd.Parameters.AddWithValue("@Stock", txtStock.Text.Trim());

                        sqlCmd.ExecuteNonQuery();

                        ClearData();
                        MessageBox.Show("Product is added successfully!", "Product Added Successfully", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    if (string.IsNullOrWhiteSpace(txtProductID.Text) || string.IsNullOrWhiteSpace(txtBarcode.Text) || string.IsNullOrWhiteSpace(txtProductName.Text) || string.IsNullOrWhiteSpace(txtUnitPrice.Text) || string.IsNullOrWhiteSpace(txtStock.Text))
                        MessageBox.Show("Please fill in the empty blanks!", "Product Updated Unsuccessfully", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    else if (txtUnitPrice.Text == "RM 0.00")
                        MessageBox.Show("Please provide valid value for unit price!", "Product Added Unsuccessfully", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    else
                    {
                        SqlCommand sqlCom = new SqlCommand("SELECT Category_ID FROM Category WHERE Category_Name ='" + cmbCategory.GetItemText(cmbCategory.SelectedItem) + "'", sqlCon);
                        SqlCommand sqlCmd = new SqlCommand("UPDATE Product SET Product_ID = @Product_ID, Barcode = @Barcode, Category_ID = @Category_ID, Category_Name = @Category_Name, Product_Name =  @Product_Name, Unit_Price = @Unit_Price, Stock = @Stock WHERE Product_ID = @Product_ID", sqlCon);

                        category_ID = sqlCom.ExecuteScalar().ToString();

                        sqlCmd.Parameters.AddWithValue("@Product_ID", txtProductID.Text);
                        sqlCmd.Parameters.AddWithValue("@Barcode", txtBarcode.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@Category_ID", category_ID);
                        sqlCmd.Parameters.AddWithValue("@Category_Name", cmbCategory.GetItemText(cmbCategory.SelectedItem));
                        sqlCmd.Parameters.AddWithValue("@Product_Name", txtProductName.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@Unit_Price", float.Parse(txtUnitPrice.Text.Remove(0, 3)).ToString("N2"));
                        sqlCmd.Parameters.AddWithValue("@Stock", txtStock.Text.Trim());
                        
                        sqlCmd.ExecuteNonQuery();

                        ClearData();
                        MessageBox.Show("Product is updated successfully!", "Product Updated Successfully", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                DisplayData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
            finally
            {
                sqlCon.Close();
            }
        }

        //Allow Manager to Delete Product's Details 
        private void btnDeleteProduct_Click(object sender, EventArgs e)
        {
            DialogResult Result = MessageBox.Show("Are you sure you want to delete?", "Delete Selected Product", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (Result == DialogResult.Yes)
            {
                try
                {
                    if (sqlCon.State == ConnectionState.Closed)
                        sqlCon.Open();

                    SqlCommand sqlCmd = new SqlCommand("DELETE Product WHERE Product_ID = @Product_ID", sqlCon);
                    sqlCmd.Parameters.AddWithValue("@Product_ID", txtProductID.Text);

                    sqlCmd.ExecuteNonQuery();

                    ClearData();
                    DisplayData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error Message");
                }
            }
        }

        private void btnProductID_Click(object sender, EventArgs e)
        {
            SqlCommand sqlCmd = new SqlCommand("SELECT MAX(Product_ID) FROM Product HAVING MAX(Product_ID) IS NOT NULL", sqlCon); //http://stackoverflow.com/questions/14154087/return-no-row-if-max-query-return-a-null

            try
            {
                if (sqlCon.State == ConnectionState.Closed)
                    sqlCon.Open();

                using (SqlDataReader sqlRead = sqlCmd.ExecuteReader())
                {
                    if (sqlRead.HasRows)
                    {
                        sqlRead.Close();

                        txtProductID.Text = (int.Parse(sqlCmd.ExecuteScalar().ToString()) + 1).ToString();
                    }

                    else
                        txtProductID.Text = "1";

                    txtProductID.Show();
                    btnProductID.Hide();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
            finally
            {
                sqlCon.Close();
            }
        }

        private void btnAddCategory_Click(object sender, EventArgs e)
        {
            Manager_Category F_Manager_Category = new Manager_Category();
            F_Manager_Category.Show();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ClearData();
        }

        private void NumbersOnly_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !Char.IsDigit(e.KeyChar) && (e.KeyChar != 8);
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            DisplayData();
        }

        private void txtUnitPrice_Click(object sender, EventArgs e)
        {
            Manager_Calculator F_Manager_Calculator = new Manager_Calculator();
            F_Manager_Calculator.Owner = this;
            F_Manager_Calculator.Show();
        }

        private void txtUnitPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            Manager_Calculator F_Manager_Calculator = new Manager_Calculator();
            F_Manager_Calculator.Owner = this;
            F_Manager_Calculator.Show();

            e.Handled = (e.KeyChar != 8);
        }

        //http://stackoverflow.com/questions/8321871/how-to-make-a-textbox-accept-only-alphabetic-characters
        private void txtProductName_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back);
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();

            SqlDataAdapter sqlDa = new SqlDataAdapter("ViewOrSearchProducts", sqlCon);
            sqlDa.SelectCommand.CommandType = CommandType.StoredProcedure;
            sqlDa.SelectCommand.Parameters.AddWithValue("@Barcode", txtSearch.Text.Trim());
            DataTable dtbl = new DataTable();
            sqlDa.Fill(dtbl);
            dgvProductDetails.DataSource = dtbl;

            sqlCon.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtSearch.Clear();
        }
    }
}
