﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Grocery_Management_System__IOOP_
{
    public partial class Manager_Promotions : Form
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=IOOP_Database;Integrated Security=True");

        public Manager_Promotions()
        {
            InitializeComponent();
        }

        //Search for particular promotion details and display promotion details in data grid view
        void FillDataGridView()
        {
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();

            SqlDataAdapter sqlDa = new SqlDataAdapter("ViewOrSearchPromotion", sqlCon);
            sqlDa.SelectCommand.CommandType = CommandType.StoredProcedure;
            sqlDa.SelectCommand.Parameters.AddWithValue("@Barcode", txtSearch.Text.Trim());
            DataTable dtbl = new DataTable();
            sqlDa.Fill(dtbl);
            dgvPromotionDetails.DataSource = dtbl;

            sqlCon.Close();
        }

        //Clear the text box and set date time picker to default
         public void Reset()
        {
            txtPromotionID.Hide();
            btnPromotionID.Show();
            txtPromotionID.Text = txtBarcode.Text = txtDiscount.Text = "";
            dtpPromotionStart.Value = dtpPromotionEnd.Value = DateTime.Today; //http://stackoverflow.com/questions/3501432/setting-default-value-of-datetimepicker
            btnAddPromotion.Text = "Add Promotion";
        }


        //Display promotion details in data grid view and clear all text box when form load
        private void Manager_Promotions_Load(object sender, EventArgs e)
        {
            Reset();
            FillDataGridView();
            ////TODO: This line of code loads data into the 'iOOP_DatabaseDataSet.Promotion' table. You can move, or remove it, as needed.
            //this.promotionTableAdapter.Fill(this.iOOP_DatabaseDataSet.Promotion);
        }

        //https://www.youtube.com/watch?v=-2UcDV4uUu8
        //Add and Update promotion
        private void btnAddPromotion_Click(object sender, EventArgs e)
        {
            try
            {
                if (sqlCon.State == ConnectionState.Closed)
                    sqlCon.Open();

                SqlCommand sqlcmd = new SqlCommand("SELECT COUNT(*) FROM Product WHERE Barcode = @check", sqlCon);
                sqlcmd.Parameters.AddWithValue("@check", txtBarcode.Text);
                int countBarcode = (int)sqlcmd.ExecuteScalar();

                if (btnAddPromotion.Text == "Add Promotion")
                {
                    //check no empty textbox
                    //http://stackoverflow.com/questions/6156458/check-if-textbox-is-empty-and-return-messagebox
                    if (string.IsNullOrWhiteSpace(txtBarcode.Text) || string.IsNullOrWhiteSpace(txtDiscount.Text))
                        MessageBox.Show("Please fill in the empty blanks!", "Promotion Added Unsuccessfully", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    else if (string.IsNullOrEmpty(txtPromotionID.Text))
                        MessageBox.Show("Please generate a Promotion ID!", "Promotion Added Unsuccessfully", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    else if (countBarcode != 0)
                        MessageBox.Show("Barcode existed, please provide a different barcode!", "Product Added Unsuccessfully", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    else
                    {
                        SqlCommand sqlCmd = new SqlCommand("AddOrUpdatePromotion", sqlCon);
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.Parameters.AddWithValue("@mode", "Add");
                        sqlCmd.Parameters.AddWithValue("@Promotion_ID", txtPromotionID.Text);
                        sqlCmd.Parameters.AddWithValue("@Barcode", txtBarcode.Text.Trim()); //Trim() will remove extra spaces on left and right side of a string
                        sqlCmd.Parameters.AddWithValue("@Discount", txtDiscount.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@Promotion_Start_Date", dtpPromotionStart.Value.Date); //https://www.codeproject.com/Questions/226744/How-to-INSERT-date-into-sql-db-date-column-using-d
                        sqlCmd.Parameters.AddWithValue("@Promotion_End_Date", dtpPromotionEnd.Value.Date);

                        sqlCmd.ExecuteNonQuery();

                        Reset();
                        MessageBox.Show("Promotion is added successfully!", "Promotion Added Successfully", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    if (string.IsNullOrWhiteSpace(txtBarcode.Text) || string.IsNullOrWhiteSpace(txtDiscount.Text))
                        MessageBox.Show("Please fill in the empty blanks!", "Promotion Updated Unsuccessfully", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    else
                    {
                        SqlCommand sqlCmd = new SqlCommand("AddOrUpdatePromotion", sqlCon);
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.Parameters.AddWithValue("@mode", "Update");
                        sqlCmd.Parameters.AddWithValue("@Promotion_ID", txtPromotionID.Text);
                        sqlCmd.Parameters.AddWithValue("@Barcode", txtBarcode.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@Discount", txtDiscount.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@Promotion_Start_Date", dtpPromotionStart.Value.Date);
                        sqlCmd.Parameters.AddWithValue("@Promotion_End_Date", dtpPromotionEnd.Value.Date);

                        sqlCmd.ExecuteNonQuery();

                        Reset();
                        MessageBox.Show("Promotion is updated successfully!", "Promotion Updated Successfully", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                FillDataGridView();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
            finally
            {
                sqlCon.Close();
            }
        }

        //Display details of selected rows on text box and date time picker
        private void dgvPromotionDetails_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvPromotionDetails.Rows.Count != 0)
            {
                btnPromotionID.Hide();
                txtPromotionID.Show();

                txtPromotionID.Text = dgvPromotionDetails.CurrentRow.Cells[0].Value.ToString();
                txtBarcode.Text = dgvPromotionDetails.CurrentRow.Cells[1].Value.ToString();
                txtDiscount.Text = dgvPromotionDetails.CurrentRow.Cells[2].Value.ToString();
                dtpPromotionStart.Value = Convert.ToDateTime(dgvPromotionDetails.CurrentRow.Cells[3].Value.ToString()); //http://stackoverflow.com/questions/28261927/how-do-i-insert-value-to-datetimepicker-by-clicking-datagridview-cells-in-c
                dtpPromotionEnd.Value = Convert.ToDateTime(dgvPromotionDetails.CurrentRow.Cells[4].Value.ToString());

                btnAddPromotion.Text = "Update Promotion";
            }
            else
                MessageBox.Show("Please add in promotion details!", "No Promotion Found", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        //Run Reset() Function
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Reset();
        }

        //Delete selected promotion details
        private void btnDeletePromotion_Click(object sender, EventArgs e)
        {
             DialogResult Result = MessageBox.Show("Are you sure you want to delete?", "Delete Selected Promotion", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

             if (Result == DialogResult.Yes)
             {
                 try
                 {
                     if (sqlCon.State == ConnectionState.Closed)
                         sqlCon.Open();

                     SqlCommand sqlCmd = new SqlCommand("DeletePromotion", sqlCon);
                     sqlCmd.CommandType = CommandType.StoredProcedure;
                     sqlCmd.Parameters.AddWithValue("@Promotion_ID", txtPromotionID.Text);

                     sqlCmd.ExecuteNonQuery();

                     Reset();
                     FillDataGridView();
                     //this.promotionTableAdapter.Fill(this.iOOP_DatabaseDataSet.Promotion);
                 }
                 catch (Exception ex)
                 {
                     MessageBox.Show(ex.Message, "Error Message");
                 }
             }
        }

        //Run FillDataGridView() Function
        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                FillDataGridView();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }

            if (txtSearch.Text.Replace(" ", String.Empty) == "")
                FillDataGridView();
        }

        //Clear Search text box
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtSearch.Clear();
        }

        //Generate a Promotion ID after button clicked
        private void btnPromotionID_Click(object sender, EventArgs e)
        {
            SqlCommand sqlCmd = new SqlCommand("SELECT TOP 1 Promotion_ID FROM Promotion ORDER BY Promotion_ID DESC", sqlCon); //http://www.w3schools.com/SQl/sql_func_last.asp

            try
            {
                if (sqlCon.State == ConnectionState.Closed)
                    sqlCon.Open();

                //http://stackoverflow.com/questions/4318582/c-sharp-sql-query-if-else-based-on-results-null
                using (SqlDataReader sqlRead = sqlCmd.ExecuteReader())
                {
                    if (sqlRead.HasRows)
                    {
                        sqlRead.Close(); //http://stackoverflow.com/questions/18475195/error-there-is-already-an-open-datareader-associated-with-this-command-which-mu

                        string PromotionID = "P";

                        for (int i = 0; i < ((sqlCmd.ExecuteScalar().ToString().Remove(0, 1).Length) - ((int.Parse(sqlCmd.ExecuteScalar().ToString().Remove(0, 1)) + 1)).ToString().Length); i++)
                            PromotionID += "0";

                        txtPromotionID.Text = (PromotionID += (int.Parse(sqlCmd.ExecuteScalar().ToString().Remove(0, 1)) + 1).ToString()).ToString();
                    }

                    else
                        txtPromotionID.Text = "P01";

                    txtPromotionID.Show();
                    btnPromotionID.Hide();
                    
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
            finally
            {
                sqlCon.Close();
            }
        }

        private void NumbersOnly_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !Char.IsDigit(e.KeyChar) && (e.KeyChar != 8);
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            FillDataGridView();
        }
    }
}
