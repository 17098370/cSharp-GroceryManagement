﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Grocery_Management_System__IOOP_
{
    public partial class Manager_Login : Form
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=IOOP_Database;Integrated Security=True");

        public Manager_Login()
        {
            InitializeComponent();
        }

        //System Shadow
        protected override CreateParams CreateParams
        {
            get
            {
                const int CS_DROPSHADOW = 0x20000;
                CreateParams cp = base.CreateParams;
                cp.ClassStyle |= CS_DROPSHADOW;
                return cp;
            }
        }

        //Dragable borderless form
        private bool _dragging = false;
        private Point _start_point = new Point(0, 0);
        private void pnlTop_MouseDown(object sender, MouseEventArgs e)
        {
            _dragging = true;  // _dragging is your variable flag
            _start_point = new Point(e.X, e.Y);
        }

        private void pnlTop_MouseUp(object sender, MouseEventArgs e)
        {
            _dragging = false;
        }

        private void pnlTop_MouseMove(object sender, MouseEventArgs e)
        {
            if (_dragging)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X - this._start_point.X, p.Y - this._start_point.Y);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                if (sqlCon.State == ConnectionState.Closed)
                    sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("SELECT * FROM Account_Login WHERE Username='" + txtUsername.Text + "'AND Login_Password='" + txtPassword.Text + "'AND Login_User='Manager'", sqlCon);

                using (SqlDataReader sqlDr = sqlCmd.ExecuteReader())
                {
                    if (sqlDr.HasRows)
                    {
                        sqlDr.Read();

                        MessageBox.Show("Welcome Back " + sqlDr["Login_User"] + " " + sqlDr["First_Name"] + "!", "Login Successfully", MessageBoxButtons.OK, MessageBoxIcon.Information); //http://stackoverflow.com/questions/23731515/how-to-display-the-users-name-on-a-messagebox-in-c

                        Manager F_Manager = new Manager();

                        this.Hide();
                        //(this.Owner as Cashier).Hide(); //Hide cashier form when manager login to manager view
                        F_Manager.LogoutTo = "Cashier"; // When manager login from cashier page, when manager logout, it will load back to cashier page
                        F_Manager.Show();
                    }
                    else
                        MessageBox.Show("Invalid Username or Password!", "Login Unsuccessfully", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
            finally
            {
                sqlCon.Close();
            }
        }
    }
}
