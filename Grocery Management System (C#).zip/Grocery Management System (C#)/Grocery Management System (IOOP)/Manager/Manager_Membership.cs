﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Grocery_Management_System__IOOP_
{
    public partial class Manager_Membership : Form
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=IOOP_Database;Integrated Security=True");

        public Manager_Membership()
        {
            InitializeComponent();
        }

        public void FillDataGridView()
        {
            Cashier_NewMember F_Cashier_NewMember = new Cashier_NewMember();

            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();

            SqlDataAdapter sqlDa = new SqlDataAdapter("ViewOrSearchMembership", sqlCon);
            sqlDa.SelectCommand.CommandType = CommandType.StoredProcedure;
            sqlDa.SelectCommand.Parameters.AddWithValue("@Member_ID", txtSearch.Text.Trim()); //http://stackoverflow.com/questions/11165537/passing-textboxs-text-to-another-form-in-c
            DataTable dtbl = new DataTable();
            sqlDa.Fill(dtbl);
            dgvMembershipDetails.DataSource = dtbl;

            sqlCon.Close();
        }

        private void btnAddMember_Click(object sender, EventArgs e)
        {
            Cashier_NewMember F_Cashier_NewMember = new Cashier_NewMember();

            F_Cashier_NewMember.Show();

            if (btnAddMember.Text == "Update Member")
            {
                F_Cashier_NewMember.btnMemberID.Hide();
                F_Cashier_NewMember.txtMemberID.Show();
                F_Cashier_NewMember.btnAddMember.Text = "Update Member";

                F_Cashier_NewMember.txtMemberID.Text = dgvMembershipDetails.CurrentRow.Cells[0].Value.ToString();
                F_Cashier_NewMember.dtpMemberSince.Value = Convert.ToDateTime(dgvMembershipDetails.CurrentRow.Cells[1].Value.ToString());
                F_Cashier_NewMember.txtPoints.Text = dgvMembershipDetails.CurrentRow.Cells[2].Value.ToString();
                F_Cashier_NewMember.cmbTitle.Text = dgvMembershipDetails.CurrentRow.Cells[3].Value.ToString();
                F_Cashier_NewMember.txtFirstName.Text = dgvMembershipDetails.CurrentRow.Cells[4].Value.ToString();
                F_Cashier_NewMember.txtLastName.Text = dgvMembershipDetails.CurrentRow.Cells[5].Value.ToString();
                F_Cashier_NewMember.dtpDOB.Value = Convert.ToDateTime(dgvMembershipDetails.CurrentRow.Cells[6].Value.ToString());
                F_Cashier_NewMember.cmbGender.Text = dgvMembershipDetails.CurrentRow.Cells[7].Value.ToString();
                F_Cashier_NewMember.cmbMobileNo.Text = dgvMembershipDetails.CurrentRow.Cells[8].Value.ToString().Substring(0, 3);
                F_Cashier_NewMember.txtMobileNo.Text = dgvMembershipDetails.CurrentRow.Cells[8].Value.ToString().Remove(0, 3);
                F_Cashier_NewMember.cmbHomeNo.Text = dgvMembershipDetails.CurrentRow.Cells[9].Value.ToString().Substring(0, 2);
                F_Cashier_NewMember.txtHomeNo.Text = dgvMembershipDetails.CurrentRow.Cells[9].Value.ToString().Remove(0, 2);
                F_Cashier_NewMember.txtAddress.Text = dgvMembershipDetails.CurrentRow.Cells[10].Value.ToString();
                F_Cashier_NewMember.txtPostcode.Text = dgvMembershipDetails.CurrentRow.Cells[11].Value.ToString();
                F_Cashier_NewMember.txtCity.Text = dgvMembershipDetails.CurrentRow.Cells[12].Value.ToString();
                F_Cashier_NewMember.txtState.Text = dgvMembershipDetails.CurrentRow.Cells[13].Value.ToString();
                F_Cashier_NewMember.txtCountry.Text = dgvMembershipDetails.CurrentRow.Cells[14].Value.ToString();
            }
        }

        private void Manager_Membership_Load(object sender, EventArgs e)
        {
            FillDataGridView();
            // TODO: This line of code loads data into the 'iOOP_DatabaseDataSet.Member' table. You can move, or remove it, as needed.
            //this.memberTableAdapter.Fill(this.iOOP_DatabaseDataSet.Member);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            btnAddMember.Text = "Add Member";
        }

        private void dgvMembershipDetails_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Cashier_NewMember F_Cashier_NewMember = new Cashier_NewMember();

            if (dgvMembershipDetails.Rows.Count != 0)
            {
                btnAddMember.Text = "Update Member";
            }
            else
                MessageBox.Show("Please add in membership details!", "No Memberships Found", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void btnDeleteMember_Click(object sender, EventArgs e)
        {
            DialogResult Result = MessageBox.Show("Are you sure you want to delete?", "Delete Selected Member", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (Result == DialogResult.Yes)
            {
                try
                {
                    if (sqlCon.State == ConnectionState.Closed)
                        sqlCon.Open();

                    SqlCommand sqlCmd = new SqlCommand("DeleteMembership", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@Member_ID", dgvMembershipDetails.CurrentRow.Cells[0].Value.ToString());

                    sqlCmd.ExecuteNonQuery();

                    FillDataGridView();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error Message");
                }
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            FillDataGridView();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                FillDataGridView();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }

            if (txtSearch.Text.Replace(" ", String.Empty) == "")
                FillDataGridView();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtSearch.Clear();
        }
    }
}
