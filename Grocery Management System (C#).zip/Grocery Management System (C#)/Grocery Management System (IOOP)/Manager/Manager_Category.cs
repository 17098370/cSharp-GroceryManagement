﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Grocery_Management_System__IOOP_
{
    public partial class Manager_Category : Form
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=IOOP_Database;Integrated Security=True");

        public Manager_Category()
        {
            InitializeComponent();
        }

        //System Shadow
        protected override CreateParams CreateParams
        {
            get
            {
                const int CS_DROPSHADOW = 0x20000;
                CreateParams cp = base.CreateParams;
                cp.ClassStyle |= CS_DROPSHADOW;
                return cp;
            }
        }

        //Dragable borderless form
        private bool _dragging = false;
        private Point _start_point = new Point(0, 0);

        private void pnlTop_MouseDown(object sender, MouseEventArgs e)
        {
            _dragging = true;  // _dragging is your variable flag
            _start_point = new Point(e.X, e.Y);
        }

        private void pnlTop_MouseUp(object sender, MouseEventArgs e)
        {
            _dragging = false;
        }

        private void pnlTop_MouseMove(object sender, MouseEventArgs e)
        {
            if (_dragging)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X - this._start_point.X, p.Y - this._start_point.Y);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Manager_Category_Load(object sender, EventArgs e)
        {
            DisplayData();
        }

        //Display data from Mssql in Datagridview 
        private void DisplayData()
        {
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();

            DataTable dtbl = new DataTable();
            SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * FROM Category", sqlCon);
            sqlDa.Fill(dtbl);
            dgvCategoryDetails.DataSource = dtbl;

            sqlCon.Close();
        }

        //Clear Data  
        private void ClearData()
        {
            btnCategoryID.Show();
            txtCategoryID.Hide();
            txtCategoryID.Text = txtCategoryName.Text = "";
            btnAddCategory.Text = "Add Category";
        }

        //Allow Manager to add Category
        private void btnAddCategory_Click(object sender, EventArgs e)
        {
            try
            {

                if (sqlCon.State == ConnectionState.Closed)
                    sqlCon.Open();

                if (btnAddCategory.Text == "Add Category")
                {
                    if (string.IsNullOrWhiteSpace(txtCategoryName.Text))
                        MessageBox.Show("Please fill in the empty blanks!", "Category Added Unsuccessfully", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    else if (string.IsNullOrEmpty(txtCategoryID.Text))
                        MessageBox.Show("Please generate a Category ID!", "Category Added Unsuccessfully", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    else
                    {
                        SqlCommand sqlCmd = new SqlCommand("INSERT INTO Category VALUES(@Category_ID, @Category_Name)", sqlCon);

                        sqlCmd.Parameters.AddWithValue("@Category_ID", txtCategoryID.Text);
                        sqlCmd.Parameters.AddWithValue("@Category_Name", txtCategoryName.Text.Trim());

                        sqlCmd.ExecuteNonQuery();

                        ClearData();
                        MessageBox.Show("Product category is added successfully!", "Category Added Successfully", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    if (string.IsNullOrWhiteSpace(txtCategoryName.Text))
                        MessageBox.Show("Please fill in the empty blanks!", "Category Added Unsuccessfully", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    else
                    {
                        SqlCommand sqlCmd = new SqlCommand("UPDATE Category SET Category_ID = @Category_ID, Category_Name = @Category_Name WHERE Category_ID = @Category_ID", sqlCon);
                        SqlCommand sqlCom = new SqlCommand("UPDATE Product SET Category_ID = @Category_ID, Category_Name = @Category_Name WHERE Category_ID = @Category_ID", sqlCon);

                        sqlCmd.Parameters.AddWithValue("@Category_ID", txtCategoryID.Text);
                        sqlCmd.Parameters.AddWithValue("@Category_Name", txtCategoryName.Text.Trim());
                        sqlCom.Parameters.AddWithValue("@Category_ID", txtCategoryID.Text);
                        sqlCom.Parameters.AddWithValue("@Category_Name", txtCategoryName.Text.Trim());

                        sqlCmd.ExecuteNonQuery();
                        sqlCom.ExecuteNonQuery();

                        ClearData();
                        MessageBox.Show("Product category is updated successfully!", "Category Updated Successfully", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                DisplayData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
            finally
            {
                sqlCon.Close();
            }
        }

        //Allow Manager to Delete Category
        private void btnDeleteCategory_Click(object sender, EventArgs e)
        {
            DialogResult Result = MessageBox.Show("Are you sure you want to delete? Products from the selected category will be deleted as well.", "Delete Selected Category", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (Result == DialogResult.Yes)
            {
                try
                {
                    if (sqlCon.State == ConnectionState.Closed)
                        sqlCon.Open();

                    SqlCommand sqlCmd = new SqlCommand("DELETE Product WHERE Category_ID = @Category_ID", sqlCon);
                    SqlCommand sqlCom = new SqlCommand("DELETE Category WHERE Category_ID = @Category_ID", sqlCon);

                    sqlCmd.Parameters.AddWithValue("@Category_ID", txtCategoryID.Text);
                    sqlCom.Parameters.AddWithValue("@Category_ID", txtCategoryID.Text);

                    sqlCmd.ExecuteNonQuery();
                    sqlCom.ExecuteNonQuery();

                    ClearData();
                    DisplayData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error Message");
                }
            }
        }

        private void dgvCategoryDetails_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvCategoryDetails.Rows.Count != 0)
            {
                btnCategoryID.Hide();
                txtCategoryID.Show();

                txtCategoryID.Text = dgvCategoryDetails.CurrentRow.Cells[0].Value.ToString();
                txtCategoryName.Text = dgvCategoryDetails.CurrentRow.Cells[1].Value.ToString();

                btnAddCategory.Text = "Update Category";
            }
            else
                MessageBox.Show("Please add in category details!", "No Category Found", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void btnCategoryID_Click(object sender, EventArgs e)
        {
            SqlCommand sqlCmd = new SqlCommand("SELECT MAX(Category_ID) FROM Category", sqlCon); //http://www.w3schools.com/SQl/sql_func_last.asp

            try
            {
                if (sqlCon.State == ConnectionState.Closed)
                    sqlCon.Open();

                using (SqlDataReader sqlRead = sqlCmd.ExecuteReader())
                {
                    if (sqlRead.HasRows)
                    {
                        sqlRead.Close();

                        txtCategoryID.Text = (int.Parse(sqlCmd.ExecuteScalar().ToString()) + 1).ToString();
                    }

                    else
                        txtCategoryID.Text = "1";

                    txtCategoryID.Show();
                    btnCategoryID.Hide();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
            finally
            {
                sqlCon.Close();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ClearData();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();

            SqlDataAdapter sqlDa = new SqlDataAdapter("ViewOrSearchCategory", sqlCon);
            sqlDa.SelectCommand.CommandType = CommandType.StoredProcedure;
            sqlDa.SelectCommand.Parameters.AddWithValue("@Category_Name", txtSearch.Text.Trim());
            DataTable dtbl = new DataTable();
            sqlDa.Fill(dtbl);
            dgvCategoryDetails.DataSource = dtbl;

            sqlCon.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtSearch.Clear();
        }
    }
}
