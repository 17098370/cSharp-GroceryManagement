﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

using System.Web;
using System.Configuration;
using Microsoft.Reporting.WinForms;

namespace Grocery_Management_System__IOOP_
{
    public partial class Manager_Reports : Form
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=IOOP_Database;Integrated Security=True");

        public Manager_Reports()
        {
            InitializeComponent();
        }

        private void Manager_Reports_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'IOOP_DatabaseDataSet.Product' table. You can move, or remove it, as needed.
            this.ProductTableAdapter.Fill(this.IOOP_DatabaseDataSet.Product);
            //this.rptInventoryStock.RefreshReport();
            this.rptInventoryStock.RefreshReport();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (txtSearch.Text == "")
                {
                    this.ProductTableAdapter.Fill(this.IOOP_DatabaseDataSet.Product);
                    this.rptInventoryStock.RefreshReport();
                }
                else
                {
                    this.ProductTableAdapter.FillBy(this.IOOP_DatabaseDataSet.Product, ((int)(System.Convert.ChangeType(txtSearch.Text.Trim(), typeof(int)))));
                    this.rptInventoryStock.RefreshReport();
                }
                 
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtSearch.Clear();
        }
    }
}
