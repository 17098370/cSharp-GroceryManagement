﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Grocery_Management_System__IOOP_
{
    public partial class Manager_Calculator : Form
    {
        public Manager_Calculator()
        {
            InitializeComponent();
        }

        //System Shadow
        protected override CreateParams CreateParams
        {
            get
            {
                const int CS_DROPSHADOW = 0x20000;
                CreateParams cp = base.CreateParams;
                cp.ClassStyle |= CS_DROPSHADOW;
                return cp;
            }
        }

        //Dragable borderless form
        private bool _dragging = false;
        private Point _start_point = new Point(0, 0);

        private void pnlTop_MouseDown(object sender, MouseEventArgs e)
        {
            _dragging = true;
            _start_point = new Point(e.X, e.Y);
        }

        private void pnlTop_MouseUp(object sender, MouseEventArgs e)
        {
            _dragging = false;
        }

        private void pnlTop_MouseMove(object sender, MouseEventArgs e)
        {
            if (_dragging)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X - this._start_point.X, p.Y - this._start_point.Y);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            lblUnitPrice.Text = "RM 0.00";
        }

        private void btnRinggit_Click(object sender, EventArgs e)
        {
            Button btnRinggit = (Button)sender;
            float currentAmount;

            currentAmount = float.Parse(lblUnitPrice.Text.ToString().Remove(0, 3));

            if (btnRinggit.Text == "50c" || btnRinggit.Text == "20c" || btnRinggit.Text == "10c")
            {
                currentAmount += float.Parse((("0.") + (btnRinggit.Text.ToString().Remove(btnRinggit.Text.ToString().Length - 1))).ToString());
            }
            else if (btnRinggit.Text == "5c")
            {
                currentAmount += float.Parse((("0.0") + (btnRinggit.Text.ToString().Remove(btnRinggit.Text.ToString().Length - 1))).ToString());
            }
            else
            {
                currentAmount += float.Parse(btnRinggit.Text.ToString().Remove(0, 3));
            }

            lblUnitPrice.Text = "RM " + currentAmount.ToString("N2");
        }

        private void btnDone_Click(object sender, EventArgs e)
        {
            if (lblUnitPrice.Text == "RM 0.00")
                MessageBox.Show("Please provide valid value for unit price!", "Unit Price Added Unsuccessfully", MessageBoxButtons.OK, MessageBoxIcon.Error);

            else
            {
                (this.Owner as Manager_Products).txtUnitPrice.Text = lblUnitPrice.Text;
                this.Close();
            }
        }
    }
}
