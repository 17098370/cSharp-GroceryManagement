﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Globalization;

namespace Grocery_Management_System__IOOP_
{
    public partial class Cashier_Discount : Form
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=IOOP_Database;Integrated Security=True");

        Cashier cashier;
        public double discount;

        public Cashier_Discount()
        {
            InitializeComponent();
        }

        public string Cd_Discount//same like just now that one, one set one get, can u put those code in other event than the textchanged? cause u can see the event must be somehow trigered by other 3 things in the code, and since i  really not understand the whole code u did idk where got what event so hard to find so maybe try put in other event that won't be trigered 4 times idk where to put ady, i try put in 
        {
            get { return discount.ToString(); }
        }

        //System Shadow
        protected override CreateParams CreateParams
        {
            get
            {
                const int CS_DROPSHADOW = 0x20000;
                CreateParams cp = base.CreateParams;
                cp.ClassStyle |= CS_DROPSHADOW;
                return cp;
            }
        }

        //Dragable borderless form
        private bool _dragging = false;
        private Point _start_point = new Point(0, 0);

        private void pnlTop_MouseDown(object sender, MouseEventArgs e)
        {
            _dragging = true;
            _start_point = new Point(e.X, e.Y);
        }

        private void pnlTop_MouseUp(object sender, MouseEventArgs e)
        {
            _dragging = false;
        }

        private void pnlTop_MouseMove(object sender, MouseEventArgs e)
        {
            if (_dragging)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X - this._start_point.X, p.Y - this._start_point.Y);
            }
        }
        ////////////////////////////////////////////////////////////////////////////////////////////

        //Close Cashier Discount form
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void Cashier_Discount_Load(object sender, EventArgs e)
        {
            double discount = 0;
            // TODO: This line of code loads data into the 'iOOP_DatabaseDataSet.Promotion' table. You can move, or remove it, as needed.
            //this.promotionTableAdapter.Fill(this.iOOP_DatabaseDataSet.Promotion);

            //Cashier F_Cashier = new Cashier();
            //F_Cashier.dgvOrderDetails


            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();

            DataTable dtbl = new DataTable();
            SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT Promotion_ID, Product_Name, Product.Barcode, Discount, Promotion_Start_Date, Promotion_End_Date FROM Promotion INNER JOIN Product ON Promotion.Barcode = Product.Barcode WHERE GETDATE() >= Promotion_Start_Date AND GETDATE() <= Promotion_End_Date", sqlCon);
            sqlDa.Fill(dtbl);


            for (int i = 0; i < dtbl.Rows.Count; i++)
            {
                lstPromotion.Items.Add(dtbl.Rows[i][1].ToString());
            }
            //lstPromotion.DataSource = dt;
            //lstPromotion.DisplayMember = "Product_Name";
            //lstPromotion.ValueMember = "Barcode";

            //MessageBox.Show(F_Cashier.dgvOrder[0][0].ToString());

            for (int i = 0; i < dtbl.Rows.Count - 1; i++)
            {
                Boolean flag = false;

                for (int j = 0; j < cashier.dgvOrderDetails.Rows.Count - 1; i++)
                {
                    MessageBox.Show(dtbl.Rows[i][1].ToString() + (" ++ ") + cashier.dgvOrderDetails.Rows[i].Cells[0].Value.ToString());

                    if (dtbl.Rows[i][1].ToString() == cashier.dgvOrderDetails.Rows[i].Cells[0].Value.ToString())
                    {
                        MessageBox.Show("hi");
                        flag = true;
                    }
                }

                if (flag == false)
                {
                    DataRow row = dtbl.Rows[i];
                    row.Delete();
                }
            }
            dgvPromotionDetails.DataSource = dtbl;

        }

        //http://stackoverflow.com/questions/19576802/transfer-items-from-one-listbox-to-another
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (lstPromotion.SelectedItem != null)
            {
                lstCurrent.Items.Add(lstPromotion.SelectedItem);
                lstPromotion.Items.Remove(lstPromotion.SelectedItem);
            }
            else
            {
                MessageBox.Show("No item selected");
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (lstCurrent.SelectedItem != null)
            {
                lstPromotion.Items.Add(lstCurrent.SelectedItem);
                lstCurrent.Items.Remove(lstCurrent.SelectedItem);
                MessageBox.Show("hi");
            }
            else
            {
                MessageBox.Show("No item selected");
            }

        }

        private void btnAddAll_Click(object sender, EventArgs e)
        {


            for (int i = 0; i < lstPromotion.Items.Count; i++)
            {
                lstCurrent.Items.Add(lstPromotion.Items[i].ToString());
            }
            lstPromotion.Items.Clear();
        }

        private void btnDone_Click(object sender, EventArgs e)
        {

            string text;
            foreach (var items in lstCurrent.Items)
            {
                text = items.ToString();
                DataTable dtbl = new DataTable();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT Promotion_ID, Product_Name, Product.Barcode, Discount FROM Promotion INNER JOIN Product ON Promotion.Barcode = Product.Barcode WHERE Product_Name = '" + text + "'", sqlCon);
                sqlDa.Fill(dtbl);
                discount += Convert.ToDouble(dtbl.Rows[0][3]);
            }
            Cashier cashier = new Cashier();
            cashier.Cc_Discount = Cd_Discount;
            cashier.flag = true;
            (this.Owner as Cashier).lblTotalDiscount.Text = discount.ToString("c2", CultureInfo.CreateSpecificCulture("en-MY"));
            this.Hide();
            //cashier.recalculate_total();
        }
    }
}