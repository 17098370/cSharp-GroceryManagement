﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Grocery_Management_System__IOOP_
{
    public partial class Cashier_Member : Form
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=IOOP_Database;Integrated Security=True");

        public string memberID; //pass member ID to cashier page

        public Cashier_Member()
        {
            InitializeComponent();
        }

        //System Shadow
        protected override CreateParams CreateParams
        {
            get
            {
                const int CS_DROPSHADOW = 0x20000;
                CreateParams cp = base.CreateParams;
                cp.ClassStyle |= CS_DROPSHADOW;
                return cp;
            }
        }

        //Dragable borderless form
        private bool _dragging = false;
        private Point _start_point = new Point(0, 0);

        private void pnlTop_MouseDown(object sender, MouseEventArgs e)
        {
            _dragging = true;
            _start_point = new Point(e.X, e.Y);
        }

        private void pnlTop_MouseUp(object sender, MouseEventArgs e)
        {
            _dragging = false;
        }

        private void pnlTop_MouseMove(object sender, MouseEventArgs e)
        {
            if (_dragging)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X - this._start_point.X, p.Y - this._start_point.Y);
            }
        }

        //Close Cashier Member form
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
             try
             {
                 if (sqlCon.State == ConnectionState.Closed)
                     sqlCon.Open();
                 
                 SqlCommand sqlCmd = new SqlCommand("SELECT * FROM Member where Member_ID='" + txtMemberCardID.Text + "'", sqlCon);

                 using (SqlDataReader sqlDr = sqlCmd.ExecuteReader())
                 {
                     if (sqlDr.HasRows)
                     {
                         sqlDr.Read();

                         DialogResult Result = MessageBox.Show("Member ID: " + sqlDr["Member_ID"] + Environment.NewLine + "Member Name: " + sqlDr["First_Name"] + " " + sqlDr["Last_Name"] + Environment.NewLine + "Points Collected: " + sqlDr["Points_Collected"] + Environment.NewLine + Environment.NewLine + "Add Member ID to order?", "Valid Member Card ID", MessageBoxButtons.YesNo, MessageBoxIcon.Question); //https://social.msdn.microsoft.com/Forums/en-US/63a32533-377b-4f60-a26f-fd86fc611af4/how-to-display-messagebox-texts-in-multiple-lines?forum=Vsexpressvb

                         if (Result == DialogResult.Yes)
                         {
                             (this.Owner as Cashier).lblCustomer.Text = sqlDr["First_Name"].ToString() + " " + sqlDr["Last_Name"].ToString();
                             (this.Owner as Cashier).btnMember.Enabled = false; //button disabled //https://www.youtube.com/watch?v=uqjUaE3EbcY
                             memberID = sqlDr["Member_ID"].ToString(); //pass member ID to cashier page
                             this.Hide();
                         }
                     }

                     else
                         MessageBox.Show("Invalid Member Card ID!", "Invalid Member Card ID", MessageBoxButtons.OK, MessageBoxIcon.Error);
                 }
             }
             catch (Exception ex)
             {
                MessageBox.Show(ex.Message, "Error Message");
             }
             finally
             {
                sqlCon.Close();
             }
        }


    }
}
