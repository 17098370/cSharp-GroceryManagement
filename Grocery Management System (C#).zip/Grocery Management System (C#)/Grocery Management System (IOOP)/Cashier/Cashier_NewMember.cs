﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Grocery_Management_System__IOOP_
{
    public partial class Cashier_NewMember : Form
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=IOOP_Database;Integrated Security=True");

        public Cashier_NewMember()
        {
            InitializeComponent();
        }

        //System Shadow
        protected override CreateParams CreateParams
        {
            get
            {
                const int CS_DROPSHADOW = 0x20000;
                CreateParams cp = base.CreateParams;
                cp.ClassStyle |= CS_DROPSHADOW;
                return cp;
            }
        }

        //Close Cashier New Member form
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
 
        //Dragable borderless form
        private bool _dragging = false;
        private Point _start_point = new Point(0, 0);

        private void pnlTop_MouseDown(object sender, MouseEventArgs e)
        {
            _dragging = true;
            _start_point = new Point(e.X, e.Y);
        }

        private void pnlTop_MouseUp(object sender, MouseEventArgs e)
        {
            _dragging = false;
        }

        private void pnlTop_MouseMove(object sender, MouseEventArgs e)
        {
            if (_dragging)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X - this._start_point.X, p.Y - this._start_point.Y);
            }
        }

        //http://stackoverflow.com/questions/5633455/selecting-default-item-from-combobox-c-sharp
        //Selecting first item as default in combo box
        private void Cashier_NewMember_Load(object sender, EventArgs e)
        {
            Reset();
        }

        void Reset()
        {
            txtFirstName.Text = txtLastName.Text = txtMobileNo.Text = txtHomeNo.Text = txtAddress.Text = txtPostcode.Text = txtCity.Text = txtState.Text = txtCountry.Text = txtMemberID.Text =  "";
            cmbTitle.SelectedIndex = 0;
            cmbGender.SelectedIndex = 0;
            cmbMobileNo.SelectedIndex = 0;
            cmbHomeNo.SelectedIndex = 0;
            dtpDOB.Value = dtpMemberSince.Value = DateTime.Today;
            txtMemberID.Hide();
            btnMemberID.Show();
            btnAddMember.Text = "Add Member";
        }

        private void btnAddMember_Click(object sender, EventArgs e)
        {
            try
            {
                if (sqlCon.State == ConnectionState.Closed)
                    sqlCon.Open();

                if (btnAddMember.Text == "Add Member")
                {

                    if (string.IsNullOrWhiteSpace(txtFirstName.Text) || string.IsNullOrWhiteSpace(txtLastName.Text) || string.IsNullOrWhiteSpace(txtMobileNo.Text) || string.IsNullOrWhiteSpace(txtHomeNo.Text) || string.IsNullOrWhiteSpace(txtAddress.Text) || string.IsNullOrWhiteSpace(txtPostcode.Text) || string.IsNullOrWhiteSpace(txtCity.Text) || string.IsNullOrWhiteSpace(txtCountry.Text))
                        MessageBox.Show("All fields are required!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    else if (string.IsNullOrWhiteSpace(txtMemberID.Text))
                        MessageBox.Show("Please generate a Member ID!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    else
                    {
                        SqlCommand sqlCmd = new SqlCommand("AddOrUpdateMembership", sqlCon);
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.Parameters.AddWithValue("@mode", "Add");
                        sqlCmd.Parameters.AddWithValue("@Member_ID", txtMemberID.Text);
                        sqlCmd.Parameters.AddWithValue("@Member_Since_Date", dtpMemberSince.Value.Date);
                        sqlCmd.Parameters.AddWithValue("@Points_Collected", txtPoints.Text);
                        sqlCmd.Parameters.AddWithValue("@Title", cmbTitle.GetItemText(cmbTitle.SelectedItem));
                        sqlCmd.Parameters.AddWithValue("@First_Name", txtFirstName.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@Last_Name", txtLastName.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@DOB", dtpDOB.Value.Date);
                        sqlCmd.Parameters.AddWithValue("@Gender", cmbGender.GetItemText(cmbGender.SelectedItem));
                        sqlCmd.Parameters.AddWithValue("@Mobile_No", cmbMobileNo.GetItemText(cmbMobileNo.SelectedItem) + txtMobileNo.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@Home_No", cmbHomeNo.GetItemText(cmbHomeNo.SelectedItem) + txtHomeNo.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@House_Address", txtAddress.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@Post_Code", txtPostcode.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@City", txtCity.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@City_State", txtState.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@Country", txtCountry.Text.Trim());

                        sqlCmd.ExecuteNonQuery();

                        Reset();
                    }
                }
                else
                {
                    if (string.IsNullOrWhiteSpace(txtFirstName.Text) || string.IsNullOrWhiteSpace(txtLastName.Text) || string.IsNullOrWhiteSpace(txtMobileNo.Text) || string.IsNullOrWhiteSpace(txtHomeNo.Text) || string.IsNullOrWhiteSpace(txtAddress.Text) || string.IsNullOrWhiteSpace(txtPostcode.Text) || string.IsNullOrWhiteSpace(txtCity.Text) || string.IsNullOrWhiteSpace(txtCountry.Text))
                        MessageBox.Show("All fields are required!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    else
                    {
                        SqlCommand sqlCmd = new SqlCommand("AddOrUpdateMembership", sqlCon);
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.Parameters.AddWithValue("@mode", "Update");
                        sqlCmd.Parameters.AddWithValue("@Member_ID", txtMemberID.Text);
                        sqlCmd.Parameters.AddWithValue("@Member_Since_Date", dtpMemberSince.Value.Date);
                        sqlCmd.Parameters.AddWithValue("@Points_Collected", txtPoints.Text);
                        sqlCmd.Parameters.AddWithValue("@Title", cmbTitle.GetItemText(cmbTitle.SelectedItem));
                        sqlCmd.Parameters.AddWithValue("@First_Name", txtFirstName.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@Last_Name", txtLastName.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@DOB", dtpDOB.Value.Date);
                        sqlCmd.Parameters.AddWithValue("@Gender", cmbGender.GetItemText(cmbGender.SelectedItem));
                        sqlCmd.Parameters.AddWithValue("@Mobile_No", cmbMobileNo.GetItemText(cmbMobileNo.SelectedItem) + txtMobileNo.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@Home_No", cmbHomeNo.GetItemText(cmbHomeNo.SelectedItem) + txtHomeNo.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@House_Address", txtAddress.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@Post_Code", txtPostcode.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@City", txtCity.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@City_State", txtState.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@Country", txtCountry.Text.Trim());

                        sqlCmd.ExecuteNonQuery();

                        Reset();
                    }
                }
                //Update Data Grid View not working
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
            finally
            {
                sqlCon.Close();
            }
        }

        private void btnMemberID_Click(object sender, EventArgs e)
        {
            SqlCommand sqlCmd = new SqlCommand("SELECT TOP 1 Member_ID FROM Member ORDER BY Member_ID DESC", sqlCon);

            try
            {
                if (sqlCon.State == ConnectionState.Closed)
                    sqlCon.Open();

                using (SqlDataReader sqlRead = sqlCmd.ExecuteReader())
                {
                    if (sqlRead.HasRows)
                    {
                        sqlRead.Close(); //http://stackoverflow.com/questions/18475195/error-there-is-already-an-open-datareader-associated-with-this-command-which-mu

                        txtMemberID.Text = (long.Parse(sqlCmd.ExecuteScalar().ToString()) + 1).ToString();
                    }

                    else
                        txtMemberID.Text = "1300131300";

                    btnMemberID.Hide();
                    txtMemberID.Show();
                }    
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
            finally
            {
                sqlCon.Close();
            }
        }

        private void btnClearAll_Click(object sender, EventArgs e)
        {
            Reset();
        }
    }
}
