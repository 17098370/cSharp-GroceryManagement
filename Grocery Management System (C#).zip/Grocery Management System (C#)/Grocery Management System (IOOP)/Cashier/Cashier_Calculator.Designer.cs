﻿namespace Grocery_Management_System__IOOP_
{
    partial class Cashier_Calculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblAmountTendered = new System.Windows.Forms.Label();
            this.lblBalanceDue = new System.Windows.Forms.Label();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.label11 = new System.Windows.Forms.Label();
            this.lblChange = new System.Windows.Forms.Label();
            this.pnlCalculator = new System.Windows.Forms.Panel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnDone = new System.Windows.Forms.Button();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.btn50c = new System.Windows.Forms.Button();
            this.btn20c = new System.Windows.Forms.Button();
            this.btn5c = new System.Windows.Forms.Button();
            this.btn10c = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.btnRm1 = new System.Windows.Forms.Button();
            this.btnRm100 = new System.Windows.Forms.Button();
            this.btnRm50 = new System.Windows.Forms.Button();
            this.btnRm20 = new System.Windows.Forms.Button();
            this.btnRm10 = new System.Windows.Forms.Button();
            this.btnRm5 = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.panel2.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.pnlCalculator.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.pnlTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(313, 7);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(48, 15);
            this.label12.TabIndex = 30;
            this.label12.Text = "Change";
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(3, 7);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(76, 15);
            this.label10.TabIndex = 28;
            this.label10.Text = "Balance Due";
            // 
            // panel2
            // 
            this.tableLayoutPanel4.SetColumnSpan(this.panel2, 2);
            this.panel2.Controls.Add(this.lblAmountTendered);
            this.panel2.Controls.Add(this.lblBalanceDue);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(3, 25);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(242, 45);
            this.panel2.TabIndex = 33;
            // 
            // lblAmountTendered
            // 
            this.lblAmountTendered.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblAmountTendered.BackColor = System.Drawing.Color.White;
            this.lblAmountTendered.Font = new System.Drawing.Font("Century Gothic", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAmountTendered.ForeColor = System.Drawing.Color.Black;
            this.lblAmountTendered.Location = new System.Drawing.Point(123, 2);
            this.lblAmountTendered.Name = "lblAmountTendered";
            this.lblAmountTendered.Size = new System.Drawing.Size(123, 40);
            this.lblAmountTendered.TabIndex = 31;
            this.lblAmountTendered.Text = "RM 0.00";
            this.lblAmountTendered.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // lblBalanceDue
            // 
            this.lblBalanceDue.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblBalanceDue.BackColor = System.Drawing.Color.White;
            this.lblBalanceDue.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBalanceDue.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(89)))), ((int)(((byte)(152)))));
            this.lblBalanceDue.Location = new System.Drawing.Point(0, 2);
            this.lblBalanceDue.Name = "lblBalanceDue";
            this.lblBalanceDue.Size = new System.Drawing.Size(123, 40);
            this.lblBalanceDue.TabIndex = 3;
            this.lblBalanceDue.Text = "RM 0.00";
            this.lblBalanceDue.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 3;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34.34066F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34.06593F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 31.59341F));
            this.tableLayoutPanel4.Controls.Add(this.label12, 2, 0);
            this.tableLayoutPanel4.Controls.Add(this.label10, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.panel2, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.label11, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.lblChange, 2, 1);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30.13699F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 69.86301F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(364, 73);
            this.tableLayoutPanel4.TabIndex = 3;
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(137, 7);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(108, 15);
            this.label11.TabIndex = 29;
            this.label11.Text = "Amount Tendered";
            // 
            // lblChange
            // 
            this.lblChange.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblChange.BackColor = System.Drawing.Color.White;
            this.lblChange.Font = new System.Drawing.Font("Century Gothic", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChange.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblChange.Location = new System.Drawing.Point(251, 27);
            this.lblChange.Name = "lblChange";
            this.lblChange.Size = new System.Drawing.Size(110, 40);
            this.lblChange.TabIndex = 32;
            this.lblChange.Text = "RM 0.00";
            this.lblChange.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // pnlCalculator
            // 
            this.pnlCalculator.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(235)))), ((int)(((byte)(238)))));
            this.pnlCalculator.Controls.Add(this.tableLayoutPanel3);
            this.pnlCalculator.Controls.Add(this.tableLayoutPanel2);
            this.pnlCalculator.Controls.Add(this.tableLayoutPanel4);
            this.pnlCalculator.Controls.Add(this.tableLayoutPanel1);
            this.pnlCalculator.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlCalculator.Location = new System.Drawing.Point(0, 34);
            this.pnlCalculator.Name = "pnlCalculator";
            this.pnlCalculator.Size = new System.Drawing.Size(364, 361);
            this.pnlCalculator.TabIndex = 3;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.16201F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.83799F));
            this.tableLayoutPanel3.Controls.Add(this.btnClear, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.btnDone, 1, 0);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 303);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 58F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(358, 58);
            this.tableLayoutPanel3.TabIndex = 36;
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.White;
            this.btnClear.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnClear.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClear.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(89)))), ((int)(((byte)(152)))));
            this.btnClear.Location = new System.Drawing.Point(3, 3);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(169, 52);
            this.btnClear.TabIndex = 35;
            this.btnClear.Text = "CLEAR";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnDone
            // 
            this.btnDone.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(89)))), ((int)(((byte)(152)))));
            this.btnDone.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnDone.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(201)))), ((int)(((byte)(206)))));
            this.btnDone.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDone.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDone.ForeColor = System.Drawing.Color.White;
            this.btnDone.Location = new System.Drawing.Point(178, 3);
            this.btnDone.Name = "btnDone";
            this.btnDone.Size = new System.Drawing.Size(177, 52);
            this.btnDone.TabIndex = 29;
            this.btnDone.Text = "DONE";
            this.btnDone.UseVisualStyleBackColor = false;
            this.btnDone.Click += new System.EventHandler(this.btnDone_Click);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.btn50c, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.btn20c, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.btn5c, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.btn10c, 0, 2);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(252, 79);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 4;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(109, 224);
            this.tableLayoutPanel2.TabIndex = 34;
            // 
            // btn50c
            // 
            this.btn50c.BackColor = System.Drawing.Color.White;
            this.btn50c.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn50c.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btn50c.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn50c.Font = new System.Drawing.Font("Segoe UI", 17F, System.Drawing.FontStyle.Bold);
            this.btn50c.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(89)))), ((int)(((byte)(152)))));
            this.btn50c.Location = new System.Drawing.Point(3, 3);
            this.btn50c.Name = "btn50c";
            this.btn50c.Size = new System.Drawing.Size(103, 50);
            this.btn50c.TabIndex = 30;
            this.btn50c.Text = "50c";
            this.btn50c.UseVisualStyleBackColor = false;
            this.btn50c.Click += new System.EventHandler(this.btnRinggit);
            // 
            // btn20c
            // 
            this.btn20c.BackColor = System.Drawing.Color.White;
            this.btn20c.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn20c.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btn20c.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn20c.Font = new System.Drawing.Font("Segoe UI", 17F, System.Drawing.FontStyle.Bold);
            this.btn20c.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(89)))), ((int)(((byte)(152)))));
            this.btn20c.Location = new System.Drawing.Point(3, 59);
            this.btn20c.Name = "btn20c";
            this.btn20c.Size = new System.Drawing.Size(103, 50);
            this.btn20c.TabIndex = 31;
            this.btn20c.Text = "20c";
            this.btn20c.UseVisualStyleBackColor = false;
            this.btn20c.Click += new System.EventHandler(this.btnRinggit);
            // 
            // btn5c
            // 
            this.btn5c.BackColor = System.Drawing.Color.White;
            this.btn5c.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn5c.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btn5c.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn5c.Font = new System.Drawing.Font("Segoe UI", 17F, System.Drawing.FontStyle.Bold);
            this.btn5c.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(89)))), ((int)(((byte)(152)))));
            this.btn5c.Location = new System.Drawing.Point(3, 171);
            this.btn5c.Name = "btn5c";
            this.btn5c.Size = new System.Drawing.Size(103, 50);
            this.btn5c.TabIndex = 33;
            this.btn5c.Text = "5c";
            this.btn5c.UseVisualStyleBackColor = false;
            this.btn5c.Click += new System.EventHandler(this.btnRinggit);
            // 
            // btn10c
            // 
            this.btn10c.BackColor = System.Drawing.Color.White;
            this.btn10c.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn10c.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btn10c.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn10c.Font = new System.Drawing.Font("Segoe UI", 17F, System.Drawing.FontStyle.Bold);
            this.btn10c.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(89)))), ((int)(((byte)(152)))));
            this.btn10c.Location = new System.Drawing.Point(3, 115);
            this.btn10c.Name = "btn10c";
            this.btn10c.Size = new System.Drawing.Size(103, 50);
            this.btn10c.TabIndex = 32;
            this.btn10c.Text = "10c";
            this.btn10c.UseVisualStyleBackColor = false;
            this.btn10c.Click += new System.EventHandler(this.btnRinggit);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.btnRm1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnRm100, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.btnRm50, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.btnRm20, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnRm10, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.btnRm5, 0, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 79);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(246, 224);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // btnRm1
            // 
            this.btnRm1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnRm1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(89)))), ((int)(((byte)(152)))));
            this.btnRm1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnRm1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(201)))), ((int)(((byte)(206)))));
            this.btnRm1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRm1.Font = new System.Drawing.Font("Segoe UI", 17F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRm1.ForeColor = System.Drawing.Color.White;
            this.btnRm1.Location = new System.Drawing.Point(3, 4);
            this.btnRm1.Name = "btnRm1";
            this.btnRm1.Size = new System.Drawing.Size(117, 65);
            this.btnRm1.TabIndex = 35;
            this.btnRm1.Text = "RM 1";
            this.btnRm1.UseVisualStyleBackColor = false;
            this.btnRm1.Click += new System.EventHandler(this.btnRinggit);
            // 
            // btnRm100
            // 
            this.btnRm100.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnRm100.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(89)))), ((int)(((byte)(152)))));
            this.btnRm100.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(201)))), ((int)(((byte)(206)))));
            this.btnRm100.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRm100.Font = new System.Drawing.Font("Segoe UI", 17F, System.Drawing.FontStyle.Bold);
            this.btnRm100.ForeColor = System.Drawing.Color.White;
            this.btnRm100.Location = new System.Drawing.Point(126, 153);
            this.btnRm100.Name = "btnRm100";
            this.btnRm100.Size = new System.Drawing.Size(117, 65);
            this.btnRm100.TabIndex = 37;
            this.btnRm100.Text = "RM 100";
            this.btnRm100.UseVisualStyleBackColor = false;
            this.btnRm100.Click += new System.EventHandler(this.btnRinggit);
            // 
            // btnRm50
            // 
            this.btnRm50.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnRm50.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(89)))), ((int)(((byte)(152)))));
            this.btnRm50.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(201)))), ((int)(((byte)(206)))));
            this.btnRm50.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRm50.Font = new System.Drawing.Font("Segoe UI", 17F, System.Drawing.FontStyle.Bold);
            this.btnRm50.ForeColor = System.Drawing.Color.White;
            this.btnRm50.Location = new System.Drawing.Point(126, 78);
            this.btnRm50.Name = "btnRm50";
            this.btnRm50.Size = new System.Drawing.Size(117, 65);
            this.btnRm50.TabIndex = 36;
            this.btnRm50.Text = "RM 50";
            this.btnRm50.UseVisualStyleBackColor = false;
            this.btnRm50.Click += new System.EventHandler(this.btnRinggit);
            // 
            // btnRm20
            // 
            this.btnRm20.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnRm20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(89)))), ((int)(((byte)(152)))));
            this.btnRm20.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(201)))), ((int)(((byte)(206)))));
            this.btnRm20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRm20.Font = new System.Drawing.Font("Segoe UI", 17F, System.Drawing.FontStyle.Bold);
            this.btnRm20.ForeColor = System.Drawing.Color.White;
            this.btnRm20.Location = new System.Drawing.Point(126, 4);
            this.btnRm20.Name = "btnRm20";
            this.btnRm20.Size = new System.Drawing.Size(117, 65);
            this.btnRm20.TabIndex = 23;
            this.btnRm20.Text = "RM 20";
            this.btnRm20.UseVisualStyleBackColor = false;
            this.btnRm20.Click += new System.EventHandler(this.btnRinggit);
            // 
            // btnRm10
            // 
            this.btnRm10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnRm10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(89)))), ((int)(((byte)(152)))));
            this.btnRm10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnRm10.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(201)))), ((int)(((byte)(206)))));
            this.btnRm10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRm10.Font = new System.Drawing.Font("Segoe UI", 17F, System.Drawing.FontStyle.Bold);
            this.btnRm10.ForeColor = System.Drawing.Color.White;
            this.btnRm10.Location = new System.Drawing.Point(3, 153);
            this.btnRm10.Name = "btnRm10";
            this.btnRm10.Size = new System.Drawing.Size(117, 65);
            this.btnRm10.TabIndex = 7;
            this.btnRm10.Text = "RM 10";
            this.btnRm10.UseVisualStyleBackColor = false;
            this.btnRm10.Click += new System.EventHandler(this.btnRinggit);
            // 
            // btnRm5
            // 
            this.btnRm5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnRm5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(89)))), ((int)(((byte)(152)))));
            this.btnRm5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnRm5.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(201)))), ((int)(((byte)(206)))));
            this.btnRm5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRm5.Font = new System.Drawing.Font("Segoe UI", 17F, System.Drawing.FontStyle.Bold);
            this.btnRm5.ForeColor = System.Drawing.Color.White;
            this.btnRm5.Location = new System.Drawing.Point(3, 78);
            this.btnRm5.Name = "btnRm5";
            this.btnRm5.Size = new System.Drawing.Size(117, 65);
            this.btnRm5.TabIndex = 34;
            this.btnRm5.Text = "RM 5";
            this.btnRm5.UseVisualStyleBackColor = false;
            this.btnRm5.Click += new System.EventHandler(this.btnRinggit);
            // 
            // btnClose
            // 
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F);
            this.btnClose.ForeColor = System.Drawing.Color.White;
            this.btnClose.Location = new System.Drawing.Point(334, 0);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(30, 34);
            this.btnClose.TabIndex = 6;
            this.btnClose.Text = "x";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // pnlTop
            // 
            this.pnlTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(89)))), ((int)(((byte)(152)))));
            this.pnlTop.Controls.Add(this.btnClose);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(363, 34);
            this.pnlTop.TabIndex = 4;
            this.pnlTop.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlTop_MouseDown);
            this.pnlTop.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlTop_MouseMove);
            this.pnlTop.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnlTop_MouseUp);
            // 
            // Cashier_Calculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(363, 396);
            this.Controls.Add(this.pnlCalculator);
            this.Controls.Add(this.pnlTop);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Cashier_Calculator";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Mini_Calculator";
            this.panel2.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.pnlCalculator.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.pnlTop.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblChange;
        private System.Windows.Forms.Label lblAmountTendered;
        private System.Windows.Forms.Label lblBalanceDue;
        private System.Windows.Forms.Panel pnlCalculator;
        private System.Windows.Forms.Button btnDone;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button btnRm1;
        private System.Windows.Forms.Button btnRm100;
        private System.Windows.Forms.Button btnRm50;
        private System.Windows.Forms.Button btnRm20;
        private System.Windows.Forms.Button btnRm10;
        private System.Windows.Forms.Button btnRm5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Button btn50c;
        private System.Windows.Forms.Button btn20c;
        private System.Windows.Forms.Button btn5c;
        private System.Windows.Forms.Button btn10c;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Button btnClear;
    }
}