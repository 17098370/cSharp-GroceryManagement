﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;

namespace Grocery_Management_System__IOOP_
{
    public partial class Cashier_Calculator : Form
    {
        string temp;
        public float amountTendered;
        public float change;

        public Cashier_Calculator()
        {
            InitializeComponent();
        }

        //Get Total Amount from Cashier Form 
        //Ref: https://www.codeproject.com/articles/14122/passing-data-between-forms Properties Approach
        public string Cc_TotalAmount
        {
            set
            {
                temp = value;
                if (lblAmountTendered.Text == "RM 0.00")
                {
                    lblBalanceDue.Text = "RM " + temp.ToString();
                    lblChange.Text = "RM 0.00";
                }
                if (temp == "0")
                {
                    lblBalanceDue.Text = "RM 0.00";
                }

            }
        }
        //Pass Balance Due to Cashier Form
        public string Cc_BalanceDue
        {
            get { return lblBalanceDue.Text; }
         
        }

        private void btnDone_Click(object sender, EventArgs e)
        {
            if (lblBalanceDue.Text == "RM 0.00")
            {
                DialogResult Result = MessageBox.Show("Confirm?", "Payment Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (Result == DialogResult.Yes)
                {
                    amountTendered = float.Parse(lblAmountTendered.Text.Remove(0,3));
                    change = float.Parse(lblChange.Text.Remove(0, 3));
                    (this.Owner as Cashier).btnPayOrder.Text = "Confirm Order";
                    this.Close();
                }
            }
        }

        //System Shadow
        protected override CreateParams CreateParams
        {
            get
            {
                const int CS_DROPSHADOW = 0x20000;
                CreateParams cp = base.CreateParams;
                cp.ClassStyle |= CS_DROPSHADOW;
                return cp;
            }
        }

        //Dragable borderless form
        private bool _dragging = false;
        private Point _start_point = new Point(0, 0);

        private void pnlTop_MouseDown(object sender, MouseEventArgs e)
        {
            _dragging = true;
            _start_point = new Point(e.X, e.Y);
        }

        private void pnlTop_MouseUp(object sender, MouseEventArgs e)
        {
            _dragging = false;
        }

        private void pnlTop_MouseMove(object sender, MouseEventArgs e)
        {
            if (_dragging)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X - this._start_point.X, p.Y - this._start_point.Y);
            }
        }

        /////////////////////////////////////////////////////

        //Close Cashier Calculator form
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
 
        private void btnClear_Click(object sender, EventArgs e)
        {
            lblAmountTendered.Text = "RM 0.00";
        }

        ///////////////////////////////////////////////

        private void btnRinggit(object sender, EventArgs e)
        {
            Button btnRinggit = (Button)sender;
            float currentAmount;
            double change;

            currentAmount = float.Parse(lblAmountTendered.Text.ToString().Remove(0, 3));

            if (btnRinggit.Text == "50c" || btnRinggit.Text == "20c" || btnRinggit.Text == "10c")
            {
                currentAmount += float.Parse((("0.") + (btnRinggit.Text.ToString().Remove(btnRinggit.Text.ToString().Length - 1))).ToString());
            }
            else if (btnRinggit.Text == "5c")
            {
                currentAmount += float.Parse((("0.0") + (btnRinggit.Text.ToString().Remove(btnRinggit.Text.ToString().Length - 1))).ToString());
            }
            else
            {
                currentAmount += float.Parse(btnRinggit.Text.ToString().Remove(0, 3));
            }

            lblAmountTendered.Text = "RM " + currentAmount.ToString("N2");

            try
            {
                //currentAmount = float.Parse(lblAmountTendered.Text.ToString().Remove(0,3));
                //if (currentAmount.ToString() != "RM 0.00" && double.Parse(currentAmount.ToString()) < double.Parse(temp.ToString()))
                //{
                //    double balance = double.Parse(temp.ToString()) - double.Parse(currentAmount.ToString());

                //    lblBalanceDue.Text = "RM " + balance.ToString("N2");
                //    //lblBalanceDue.Text = balance.ToString("c2", CultureInfo.CreateSpecificCulture("en-MY"));
                //    lblChange.Text = "RM 0.00";
                //}
                //else if (double.Parse(currentAmount.ToString()) >= double.Parse(temp))
                //{
                //    lblBalanceDue.Text = "RM 0.00";
                //    change = double.Parse(currentAmount.ToString()) - double.Parse(temp);
                //    lblChange.Text = change.ToString();

                //    lblAmountTendered.Text = "RM " + currentAmount.ToString("N2");
                //}

                lblBalanceDue.Text = ("RM ") + ((float.Parse(temp.ToString())) - float.Parse(currentAmount.ToString())).ToString("N2");
                if (float.Parse(lblBalanceDue.Text.ToString().Remove(0, 3)) < 0)
                    lblBalanceDue.Text = ("RM 0.00");


                float a = float.Parse(currentAmount.ToString("N2"));
                float b = float.Parse(temp.ToString());
             
                lblChange.Text = ("RM ") + (a - b).ToString("N2");
                if (float.Parse(lblChange.Text.ToString().Remove(0, 3)) < 0)
                    lblChange.Text = ("RM 0.00");
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
    }
}
