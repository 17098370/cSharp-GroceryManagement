﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Microsoft.Reporting.WinForms;

namespace Grocery_Management_System__IOOP_
{
    public partial class Cashier_PrintReceipt : Form
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=IOOP_Database;Integrated Security=True");

        SqlCommand cmd, com;
        int OrderNo;

        public Cashier_PrintReceipt()
        {
            InitializeComponent();
        }

        //Print Receipt
        //http://www.aspsnippets.com/Articles/RDLC-Report-in-Windows-Forms-WinForms-Application-using-C-and-VBNet.aspx
        private void Cashier_PrintReceipt_Load(object sender, EventArgs e)
        {
            Receipt_DataSet dsReceipt = GetData();

            ReportDataSource datasource = new ReportDataSource("Receipt_DataSet", dsReceipt.Tables[0]);
            this.rptReceipt.LocalReport.DataSources.Clear();
            this.rptReceipt.LocalReport.DataSources.Add(datasource);
            this.rptReceipt.RefreshReport();
        }

        private Receipt_DataSet GetData()
        {

            sqlCon.Open();
            com = new SqlCommand("SELECT TOP 1 Order_ID FROM ReceiptTable ORDER BY Order_ID DESC", sqlCon);
            OrderNo = Convert.ToInt32(com.ExecuteScalar());

            if (OrderNo.ToString() == "0")
            {
                cmd = new SqlCommand("SELECT * FROM ReceiptTable WHERE Order_ID ='" + 1 + "'", sqlCon);
                SqlDataAdapter sda = new SqlDataAdapter();
                sda.SelectCommand = cmd;
                using (Receipt_DataSet dsReceipt = new Receipt_DataSet())
                {
                    sda.Fill(dsReceipt, "ReceiptTable");//Data table
                    return dsReceipt;
                }
            }
            else
            {
                cmd = new SqlCommand("SELECT * FROM ReceiptTable WHERE Order_ID ='" + OrderNo + "'", sqlCon);
                SqlDataAdapter sda = new SqlDataAdapter();
                sda.SelectCommand = cmd;
                using (Receipt_DataSet dsReceipt = new Receipt_DataSet())
                {
                    sda.Fill(dsReceipt, "ReceiptTable");//Data table
                    return dsReceipt;
                }
            }


        }
    }
}
