﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
//using System.Globalization;
//using System.Drawing.Printing;

namespace Grocery_Management_System__IOOP_
{
    public partial class Cashier : Form
    {
        public string isManager;
        double amount, discount;
        string balance;
        DataTable dgvOrder;
        double total;
        public bool flag;

        SqlConnection sqlCon = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=IOOP_Database;Integrated Security=True");

        public Cashier()
        {
            InitializeComponent();

            CreateTabbedPanel();
            AddProductsToTabbedPanel();

            //sqlCon.Open();
            //SqlCommand sqlCmd = new SqlCommand("SELECT TOP 1 ORDER_ID FROM TblOrder_Details ORDER BY ORDERID DESC", con);
            //OrderNo = Convert.ToInt32(com.ExecuteScalar());
            //lblOrderNumber.Text = "Order" + ((int)OrderNo + 1).ToString();
            //con.Close();
        }

                //Pass Total Amount to Calculator
        public string Cs_TotalAmount
        {
            get { return amount.ToString(); }
        }

        //Get Balance Due from Calculator
        public string Cs_BalanceDue
        {
            set
            {
                balance = value;
                lblBalanceDue.Text = balance;
            }
        }

        public string Cc_OrderNumber
        {
            get { return lblOrderNumber.ToString(); }
        }

        public string Cc_SubTotal
        {
            set { lblSubTotal.Text = value; }
        }
        public string Cc_GST
        {
            set { lblGST.Text = value; }
        }
        public string Cc_Total
        {
            set { lblTotal.Text = value; }
        }
        public string Cc_BalanceDue
        {
            set { lblBalanceDue.Text = value; }
        }
        public string Cc_Discount
        {
            set //but x working, so rachel suggested me to use text changed so mean no other event can put inorder to work?idk another choice is pass all the sum, gst value to cashier_discount and calculate there and pass it back ==
            {
                discount = double.Parse(value);
                lblTotalDiscount.Text = discount.ToString("N2");//2nd, when will this function be execute?this is just passing value, so i can use discount here
            }
        }

        //http://stackoverflow.com/questions/16493698/drop-shadow-on-a-borderless-winform
        //System Shadow
        protected override CreateParams CreateParams
        {
            get
            {
                const int CS_DROPSHADOW = 0x20000;
                CreateParams cp = base.CreateParams;
                cp.ClassStyle |= CS_DROPSHADOW;
                return cp;
            }
        }

        //http://stackoverflow.com/questions/1592876/make-a-borderless-form-movable
        //Dragable borderless form
        private bool _dragging = false;
        private Point _start_point = new Point(0, 0);

        private void pnlTop_MouseDown(object sender, MouseEventArgs e)
        {
            _dragging = true;  // _dragging is your variable flag
            _start_point = new Point(e.X, e.Y);
        }

        private void pnlTop_MouseUp(object sender, MouseEventArgs e)
        {
            _dragging = false;
        }
     
        private void pnlTop_MouseMove(object sender, MouseEventArgs e)
        {
            if (_dragging)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X - this._start_point.X, p.Y - this._start_point.Y);
            }
        }
              
        //Display Manager page when Manager View button clicked and login successfully
        private void btnManagerView_Click(object sender, EventArgs e)
        {
            if (isManager == "true")
            {
                Manager F_Manager = new Manager();
                //this.Hide();
                F_Manager.Show();
            }

            else if (isManager == "false")
            {
                Manager_Login F_Manager_Login = new Manager_Login();
                //F_Manager_Login.Owner = this;
                F_Manager_Login.Show();
            }
        }

        //Show Cashier New Member form when New Member button clicked
        private void btnNewMember_Click(object sender, EventArgs e)
        {
            Cashier_NewMember F_Cashier_NewMember = new Cashier_NewMember();
            F_Cashier_NewMember.Show();
        }

        //Show Cashier Barcode form when Barcode button clicked
        private void btnBarcode_Click(object sender, EventArgs e)
        {
            Cashier_Barcode F_Cashier_Barcode = new Cashier_Barcode(this);
            F_Cashier_Barcode.Show();
        }

        //Load back to Main page when Logout button clicked 
        private void btnLogout_Click(object sender, EventArgs e)
        {
            DialogResult Result = MessageBox.Show("Are you sure you want to Logout?", "Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (Result == DialogResult.Yes)
            {
                Main F_Main = new Main();

                this.Hide();
                F_Main.Show();
            }
        }

        //Show Chashier Discount form when Discount button clicked
        private void btnDiscount_Click(object sender, EventArgs e)
        {
            Cashier_Discount F_Cashier_Discount = new Cashier_Discount();
            F_Cashier_Discount.Show();

            dgvOrder = (DataTable)(dgvOrderDetails.DataSource);
        }

        //Show Cashier Member form when Member button is clicked
        private void btnMember_Click(object sender, EventArgs e)
        {
            Cashier_Member F_Cashier_Member = new Cashier_Member();
            F_Cashier_Member.Owner = this; //to disable member button
            F_Cashier_Member.Show();
        }

        //Show Cashier Print Receipt form when Print Receipt button is clicked
        private void btnPrintReceipt_Click(object sender, EventArgs e)
        {
            Cashier_PrintReceipt F_Cashier_PrintReceipt = new Cashier_PrintReceipt();
            F_Cashier_PrintReceipt.Show();
        }

        //Calculator Form Pop Out when Comfirm Order is clicked
        private void PayOrder_Click(object sender, EventArgs e)
        {
            Cashier_Calculator F_Cashier_Calculator = new Cashier_Calculator();

            if (btnPayOrder.Text == "Confirm Order")
            {
                try
                {
                    if (sqlCon.State == ConnectionState.Closed)
                        sqlCon.Open();

                    string barcode;
                    string posID;
                    string customerType;
                    Cashier_Member F_Cashier_Member = new Cashier_Member();
                    int points;
                    string MemberID;

                    for (int i = 0; i < dgvOrderDetails.Rows.Count; i++)
                    {
                        sqlCon.Open();
                        SqlCommand sqlCom = new SqlCommand("SELECT Barcode FROM Product WHERE Product_Name ='" + dgvOrderDetails.Rows[i].Cells[0].Value + "'", sqlCon);
                        SqlCommand sqlCmd = new SqlCommand("INSERT INTO Order_Details(Order_ID, Barcode,Product_Name,Quantity,Unit_Price,Total) VALUES(@Order_ID, @Barcode, @Product_Name, @Quantity, @Unit_Price, @Total)", sqlCon);
                        SqlCommand sqlCom2 = new SqlCommand("SELECT POS_ID FROM Account_Login WHERE POS_ID ='" + lblUser.Text.ToString().Remove(0, 8) + "'", sqlCon);
                        SqlCommand sqlCmd2 = new SqlCommand("INSERT INTO Customer_Order(Order_ID, POS_ID, Customer_Type, Member_ID, Points, Transaction_Date, Order_Total, Amount_Tendered, Change) VALUES(@Order_ID, @POS_ID, @Customer_Type, @Member_ID, @Points, @Transaction_Date, @Order_Total, @Amount_Tendered, @Change)", sqlCon);


                        barcode = sqlCom.ExecuteScalar().ToString();
                        posID = sqlCom2.ExecuteScalar().ToString();

                        if (lblCustomer.Text == "Walk In Customer")
                        {
                            customerType = lblCustomer.Text;
                            MemberID = "-";
                        }

                        else
                        {
                            customerType = "Registered Customer";
                            MemberID = F_Cashier_Member.memberID;
                        }

                        points = int.Parse(lblBalanceDue.Text) * 1;
                        DateTime date = DateTime.Today;

                        //Cashier_Calculator F_Cashier_Calculator = new Cashier_Calculator();


                        sqlCmd.Parameters.AddWithValue("@Order_ID", lblOrderNumber.Text.Remove(0, 5));
                        sqlCmd.Parameters.AddWithValue("@Barcode", barcode.ToString());
                        sqlCmd.Parameters.AddWithValue("@Product_Name", dgvOrderDetails.Rows[0].Cells[0].Value.ToString());
                        sqlCmd.Parameters.AddWithValue("@Quantity", dgvOrderDetails.Rows[0].Cells[1].Value.ToString());
                        sqlCmd.Parameters.AddWithValue("@Unit_Price", dgvOrderDetails.Rows[0].Cells[2].Value.ToString());
                        sqlCmd.Parameters.AddWithValue("@Total", dgvOrderDetails.Rows[0].Cells[3].Value.ToString());
                        MessageBox.Show((F_Cashier_Calculator.amountTendered).ToString());
                        sqlCmd2.Parameters.AddWithValue("@Order_ID", lblOrderNumber.Text.Remove(0, 5));
                        sqlCmd2.Parameters.AddWithValue("@POS_ID", posID);
                        sqlCmd2.Parameters.AddWithValue("@Customer_Type", customerType);
                        sqlCmd2.Parameters.AddWithValue("@Member_ID", MemberID);
                        sqlCmd2.Parameters.AddWithValue("@Points", points);
                        sqlCmd2.Parameters.AddWithValue("@Transaction_Date", date);
                        sqlCmd2.Parameters.AddWithValue("@Order_Total", lblTotal);
                        sqlCmd2.Parameters.AddWithValue("@Amount_Tendered", F_Cashier_Calculator.amountTendered);
                        sqlCmd2.Parameters.AddWithValue("@Change", F_Cashier_Calculator.change);

                        sqlCmd.ExecuteNonQuery();
                        sqlCmd2.ExecuteNonQuery();

                        MessageBox.Show("Order details is added saved!", "Order Details Recorded", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error Message");
                    sqlCon.Close();
                }
                finally
                {
                    sqlCon.Close();
                }
            }

            else
            {
                //F_Cashier_Calculator.Show();

                //Cashier_Calculator F_Cashier_Calculator = new Cashier_Calculator();
                F_Cashier_Calculator.Owner = this;
                F_Cashier_Calculator.Cc_TotalAmount = Cs_TotalAmount.ToString();
                F_Cashier_Calculator.Show();

                //string temp;

                //dgvOrderDetails.AllowUserToAddRows = true;
                //DataGridViewRow row = (DataGridViewRow)dgvOrderDetails.Rows[0].Clone();

                //dgvOrderDetails.Rows.Clear();
                //dgvOrderDetails.Refresh();
                //dgvOrderDetails.AllowUserToAddRows = false;
                //lblTotalDiscount.Text = "RM 0.00";
                //lblGST.Text = "RM 0.00";
                //lblSubTotal.Text = "RM 0.00";
                //lblBalanceDue.Text = "RM 0.00";
                //lblTotal.Text = "RM 0.00";
                //temp = "0.00";
                //amount = double.Parse(temp);
                
            }
        }

        //Empties all Records and Details
        private void btnCancelOrder_Click(object sender, EventArgs e)
        {
            string temp;

            dgvOrderDetails.AllowUserToAddRows = true;
            DataGridViewRow row = (DataGridViewRow)dgvOrderDetails.Rows[0].Clone();

            dgvOrderDetails.Rows.Clear();
            dgvOrderDetails.Refresh();
            dgvOrderDetails.AllowUserToAddRows = false;
            lblTotalDiscount.Text = "RM 0.00";
            lblGST.Text = "RM 0.00";
            lblSubTotal.Text = "RM 0.00";
            lblBalanceDue.Text = "RM 0.00";
            lblTotal.Text = "RM 0.00";
            temp = "0.00";
            amount = double.Parse(temp);
        }


        //https://www.dotnetperls.com/messagebox-show
        //Close system
        private void btnClose_Click(object sender, EventArgs e)
        {
            DialogResult Result =  MessageBox.Show("Are you sure you want to exit?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (Result == DialogResult.Yes)
                Application.Exit();
        }

        //Display current dates and day
        private void Cashier_Load(object sender, EventArgs e)
        {
            DateTime dateValue = DateTime.Now;
            lblDate.Text = dateValue.ToString("D");

            //if (dgvOrderDetails.Rows.Count != 0)
            //{
            //    btnPayOrder.Enabled = false;
            //}
        }

        //Display current system time
        private void tmrTime_Tick(object sender, EventArgs e)
        {
            DateTime Current_Time = DateTime.Now;
            lblTime.Text = Current_Time.ToString("hh:mm:ss  tt");
        }

        //https://msdn.microsoft.com/en-us/library/system.windows.forms.form.windowstate(v=vs.110).aspx?cs-save-lang=1&cs-lang=csharp#code-snippet-1
        //Minimized form
        private void btnMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        //Show Category
        private void CreateTabbedPanel()
        {
            sqlCon.Open();
            SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT DISTINCT Category_Name FROM Category", sqlCon);
            DataTable dtbl = new DataTable();
            sqlDa.Fill(dtbl);

            foreach (DataRow dr in dtbl.Rows)
            {
                tabProductCategory.TabPages.Add(dr["Category_Name"].ToString());
            }
            sqlCon.Close();
        }

        //Add products for Every Category in Tab Control
        private void AddProductsToTabbedPanel()
        {
            int i = 1;
            tabProductCategory.Refresh();

            foreach (TabPage tp in tabProductCategory.TabPages)
            {
                sqlCon.Open();
                SqlDataAdapter sdaProductType = new SqlDataAdapter("SELECT Product_Name FROM Product WHERE Category_ID =" + i.ToString(), sqlCon);
                FlowLayoutPanel flp = new FlowLayoutPanel();
                flp.Dock = DockStyle.Fill;
                DataTable dtbl = new DataTable();
                sdaProductType.Fill(dtbl);

                foreach (DataRow dr in dtbl.Rows)
                {
                    Button b = new Button();
                    b.Size = new Size(100, 100);
                    b.Font = new Font("Segoe UI", 12); //http://stackoverflow.com/questions/16191751/how-do-i-set-button-font-to-marlett
                    b.Text = dr["Product_Name"].ToString();
                    b.Tag = dr;
                    b.Click += new EventHandler(b_Click);
                    flp.Controls.Add(b);
                }
                tp.Controls.Add(flp);
                i++;
                sqlCon.Close();
            }
        }

        //Product's Details show in Order Details Datagridview when product's button is clicked
        //https://msdn.microsoft.com/en-us/library/ch45axte.aspx
        void b_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;

            SqlCommand sqlCmd = new SqlCommand();
            sqlCmd.Connection = sqlCon;
            sqlCmd.CommandType = CommandType.Text;
            sqlCmd.CommandText = "SELECT Product_Name, Unit_Price FROM Product WHERE Product_Name ='" + b.Text.ToString() + "'";
            SqlDataAdapter da = new SqlDataAdapter(sqlCmd);

            DataTable dtbl = new DataTable();
            da.Fill(dtbl);

            double rate = 0.06;
            double sum = 0;
            double each;
            double total;

            if (dgvOrderDetails.Rows.Count < 1)
            {
                dgvOrderDetails.Rows.Add((b.Text.ToString()), "1", (dtbl.Rows[0][1]).ToString());
                dgvOrderDetails.Rows[0].Cells[3].Value = dgvOrderDetails.Rows[0].Cells[2].Value;
            }
            else
            {
                for (int i = 0; i < dgvOrderDetails.Rows.Count; i++)
                {                   
                    if ((dgvOrderDetails.Rows[i].Cells[0].Value.ToString()) == b.Text.ToString())
                    {
                        dgvOrderDetails.Rows[i].Cells[1].Value = double.Parse(dgvOrderDetails.Rows[i].Cells[1].Value.ToString()) + 1;
                        each = double.Parse(dgvOrderDetails.Rows[i].Cells[2].Value.ToString());//good job
                        total = double.Parse(dgvOrderDetails.Rows[i].Cells[1].Value.ToString()) * each;
                        dgvOrderDetails.Rows[i].Cells[3].Value = total.ToString();
                        break;
                    }

                    else if ( i == (dgvOrderDetails.Rows.Count - 1))
                    {
                        dgvOrderDetails.Rows.Add((b.Text.ToString()), "1", (dtbl.Rows[0][1]).ToString(), (dtbl.Rows[0][1]).ToString());
                        break;
                    }       
                }          
            }

            foreach (DataGridViewRow row in dgvOrderDetails.Rows)
            {
                sum += Convert.ToDouble(row.Cells[3].Value);
            }
            lblSubTotal.Text = "RM " + sum.ToString("N2");
            double gst = sum * rate;
            lblGST.Text = "RM " + (gst).ToString("N2");
            amount = sum + gst;
            lblTotal.Text = "RM " + (amount).ToString("N2");
            lblBalanceDue.Text = "RM " + (amount).ToString("N2");
        }

        //Remove the selected Product
        private void btnRemoveItem_Click(object sender, EventArgs e)
        {
            double rate = 0.06;
            double sum = 0;

            if (dgvOrderDetails.SelectedRows.Count == 0)
            {
                MessageBox.Show("There are no items!", "No Items Found", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            foreach (DataGridViewRow row in dgvOrderDetails.SelectedRows)
            {
                if (!row.IsNewRow)
                {
                    dgvOrderDetails.Rows.Remove(row);
                    foreach (DataGridViewRow rows in dgvOrderDetails.Rows)
                    {
                        sum += Convert.ToDouble(rows.Cells[3].Value);
                    }

                    lblSubTotal.Text = "RM " + sum.ToString("N2");
                    double gst = sum * rate;
                    lblGST.Text = "RM " + (gst).ToString("N2");
                    amount = sum + gst;
                    lblTotal.Text = "RM " + (amount).ToString("N2");
                    lblBalanceDue.Text = "RM " + (amount).ToString("N2");
                }
            }
        }
    }
}
