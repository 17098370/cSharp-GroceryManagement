﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Globalization;

namespace Grocery_Management_System__IOOP_
{
    public partial class Cashier_Barcode : Form
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=IOOP_Database;Integrated Security=True");
        
        Cashier cashier;
        double sum = 0;
        double rate = 0.06;
        double each, temp, amount;
        string subtotal, gst, total;

        public Cashier_Barcode(Cashier cashier)
        {
            InitializeComponent();
            this.cashier = cashier;
        }

        public string Cb_Subtotal
        {
            get { return subtotal; }
        }

        public string Cb_GST
        {
            get { return gst; }
        }

        public string Cb_Total
        {
            get { return total; }
        }

        public string Cb_BalanceDue
        {
            get { return total; }
        }

        //System Shadow
        protected override CreateParams CreateParams
        {
            get
            {
                const int CS_DROPSHADOW = 0x20000;
                CreateParams cp = base.CreateParams;
                cp.ClassStyle |= CS_DROPSHADOW;
                return cp;
            }
        }

        //Dragable borderless form
        private bool _dragging = false;
        private Point _start_point = new Point(0, 0);

        private void pnlTop_MouseDown(object sender, MouseEventArgs e)
        {
            _dragging = true;
            _start_point = new Point(e.X, e.Y);
        }

        private void pnlTop_MouseUp(object sender, MouseEventArgs e)
        {
            _dragging = false;
        }

        private void pnlTop_MouseMove(object sender, MouseEventArgs e)
        {
            if (_dragging)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X - this._start_point.X, p.Y - this._start_point.Y);
            }
        }

        //Close Cashier Barcode form
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtBarcode_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !Char.IsDigit(e.KeyChar) && (e.KeyChar != 8);
        }

        private void btnDecrease_Click(object sender, EventArgs e)
        {
            if(lblQuantity.Text != "1")
                lblQuantity.Text = (int.Parse(lblQuantity.Text) - 1).ToString();
        }

        private void btnIncrease_Click(object sender, EventArgs e)
        {
            lblQuantity.Text = (int.Parse(lblQuantity.Text) + 1).ToString();
        }

        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            try
            {
                if (sqlCon.State == ConnectionState.Closed)
                    sqlCon.Open();

                SqlCommand cmd = new SqlCommand("Select * FROM Product WHERE Barcode ='" + txtBarcode.Text + "'", sqlCon);

                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    if (dr.HasRows)
                    {
                        dr.Read();

                        DialogResult Result = MessageBox.Show("Barcode: " + dr["Barcode"] + Environment.NewLine + "Product Name: " + dr["Product_Name"] + Environment.NewLine + "Category Name: " + dr["Category_Name"] + Environment.NewLine + " Unit Price: " + dr["Unit_Price"] + Environment.NewLine + "Add to order's details?", "Valid Barcode", MessageBoxButtons.YesNo, MessageBoxIcon.Question); //https://social.msdn.microsoft.com/Forums/en-US/63a32533-377b-4f60-a26f-fd86fc611af4/how-to-display-messagebox-texts-in-multiple-lines?forum=Vsexpressvb
                        //http://stackoverflow.com/questions/27503064/how-to-add-row-in-datagridview-from-another-form
                        if (Result == DialogResult.Yes)
                        {
                            int n = cashier.dgvOrderDetails.Rows.Add();
                            cashier.dgvOrderDetails.Rows[n].Cells[0].Value = dr["Product_Name"].ToString();
                            cashier.dgvOrderDetails.Rows[n].Cells[1].Value = lblQuantity.Text;
                            cashier.dgvOrderDetails.Rows[n].Cells[2].Value = dr["Unit_Price"].ToString();
                            cashier.dgvOrderDetails.Rows[n].Cells[3].Value = int.Parse(lblQuantity.Text) * float.Parse(dr["Unit_Price"].ToString());
                            cashier.dgvOrderDetails.Invalidate();
                            //subtotal = 
                            foreach (DataGridViewRow rows in cashier.dgvOrderDetails.Rows)
                            {
                                sum += Convert.ToDouble(rows.Cells[3].Value);
                            }

                            subtotal = "RM " + sum.ToString("N2");
                            double temp = sum * rate;
                            gst = "RM " + (temp).ToString("N2");
                            amount = sum + temp;
                            total = "RM " + (amount).ToString("N2");
                            cashier.Cc_SubTotal = Cb_Subtotal;
                            cashier.Cc_GST = Cb_GST;
                            cashier.Cc_Total = Cb_Total;
                            cashier.Cc_BalanceDue = Cb_BalanceDue;
                            this.Close();
                            this.Hide();

                        }
                    }

                    else
                        MessageBox.Show("Invalid Barcode!", "Invalid Barcode", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
            finally
            {
                sqlCon.Close();
            }
        }
    }
}