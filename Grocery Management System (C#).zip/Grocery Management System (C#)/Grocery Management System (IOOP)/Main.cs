﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Grocery_Management_System__IOOP_
{
    public partial class Main : Form
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=IOOP_Database;Integrated Security=True");

        public Main()
        {
            InitializeComponent();
        }

        //System Shadow
        protected override CreateParams CreateParams
        {
            get
            {
                const int CS_DROPSHADOW = 0x20000;
                CreateParams cp = base.CreateParams;
                cp.ClassStyle |= CS_DROPSHADOW;
                return cp;
            }
        }

        //Dragable borderless form
        private bool _dragging = false;
        private Point _start_point = new Point(0, 0);

        private void picTop_MouseDown(object sender, MouseEventArgs e)
        {
            _dragging = true;  // _dragging is your variable flag
            _start_point = new Point(e.X, e.Y);
        }

        private void picTop_MouseUp(object sender, MouseEventArgs e)
        {
            _dragging = false;
        }

        private void picTop_MouseMove(object sender, MouseEventArgs e)
        {
            if (_dragging)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X - this._start_point.X, p.Y - this._start_point.Y);
            }
        }

        //Exit system
        private void btnClose_Click(object sender, EventArgs e)
        {
            DialogResult Result = MessageBox.Show("Are you sure you want to exit?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (Result == DialogResult.Yes)
                Application.Exit();
        }

        //Minimize system
        private void btnMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        //Textbox will be underlined in blue colour and description of textbox will be cleared when clicked
        private void txtUsername_Click(object sender, EventArgs e)
        {
            Username_Click_TextChanged();
        }

        private void Username_Click_TextChanged()
        {
            //MessageBox.Show("hi");
            //http://stackoverflow.com/questions/26171975/set-windows-forms-background-color-to-hex-value
            pnlUsername.BackColor = ColorTranslator.FromHtml("#3B5998");
            pnlPassword.BackColor = ColorTranslator.FromHtml("#D6DBD2");

            //http://stackoverflow.com/questions/16346146/remove-all-whitespace-from-c-sharp-string-with-regex
            //Remove spaces from string
            txtPassword.Text = txtPassword.Text.Replace(" ", String.Empty);

            if (txtUsername.Text == "Username")
            {
                txtUsername.Clear();
            }

            //https://msdn.microsoft.com/en-us/library/system.string.isnullorwhitespace.aspx
            if (string.IsNullOrWhiteSpace(txtPassword.Text.ToString()))
            {
                txtPassword.UseSystemPasswordChar = false;
                txtPassword.Text = "Password";

            }
        }

        private void txtPassword_Click(object sender, EventArgs e)
        {
            pnlPassword.BackColor = ColorTranslator.FromHtml("#3B5998");
            pnlUsername.BackColor = ColorTranslator.FromHtml("#D6DBD2");

            txtUsername.Text = txtUsername.Text.Replace(" ", String.Empty);

            if (txtPassword.Text == "Password")
            {
                txtPassword.Clear();
            }

            if (string.IsNullOrWhiteSpace(txtUsername.Text.ToString()))
            {
                txtUsername.Text = "Username";
            }
            txtPassword.UseSystemPasswordChar = true;
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            if (txtPassword.Text != "Password" || !string.IsNullOrWhiteSpace(txtPassword.Text.ToString()))
            {
                //txtPassword.UseSystemPasswordChar = true;
            }
        }

        //Diaplay Cashier Page when login successfully
        private void btnLogin_Click(object sender, EventArgs e)
        {            
            try
            {
                if (sqlCon.State == ConnectionState.Closed)
                    sqlCon.Open();

                SqlCommand sqlCmd = new SqlCommand("SELECT * FROM Account_Login WHERE Username='" + txtUsername.Text + "'AND Login_Password='" + txtPassword.Text + "'", sqlCon);

                using (SqlDataReader sqlDr = sqlCmd.ExecuteReader())
                {
                    if (sqlDr.HasRows)
                    {
                        Cashier F_Cashier = new Cashier();
                        sqlDr.Read();

                        MessageBox.Show("Welcome Back " + sqlDr["Login_User"] + " " + sqlDr["First_Name"] + "!", "Login Successfully", MessageBoxButtons.OK, MessageBoxIcon.Information); //http://stackoverflow.com/questions/23731515/how-to-display-the-users-name-on-a-messagebox-in-c

                        if (sqlDr["Login_User"].ToString() == "Cashier")
                        {
                            this.Hide();
                            F_Cashier.isManager = "false"; //This is cashier account, so if manager wanna login from cashier page, login is needed
                            F_Cashier.Show();
                        }
                        else if (sqlDr["Login_User"].ToString() == "Manager")
                        {
                            Manager F_Manager = new Manager();

                            this.Hide();
                            F_Manager.LogoutTo = "Main"; //When manager login from main page, when manager logout, it will load back to main page
                            F_Manager.Show();
                        }
                        F_Cashier.lblUser.Text = sqlDr["Login_User"].ToString() + " " + sqlDr["POS_ID"].ToString();
                    }
                    else
                        MessageBox.Show("Invalid Username or Password!", "Login Unsuccessfully", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
            finally
            {
                sqlCon.Close();
            } 
        }

        private void Main_Load(object sender, EventArgs e)
        {
            txtUsername.SelectionStart = 0;
            txtUsername.SelectionStart = txtUsername.MaxLength;
            txtUsername.SelectedText = String.Empty;
            //txtUsername.SelectionStart = txtUsername.Text.Length;
        }

        private void txtUsername_KeyPress(object sender, KeyPressEventArgs e)
        {
            Username_Click_TextChanged();
        }

        private void txtPassword_Enter(object sender, EventArgs e)
        {
            txtPassword_Click(sender, e);
        } 
    }
}
